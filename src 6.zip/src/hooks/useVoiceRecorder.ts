import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert } from 'react-native';
import {
  AudioModule,
  RecordingPresets,
  setAudioModeAsync,
  useAudioPlayer,
  useAudioRecorder,
  useAudioRecorderState,
} from 'expo-audio';

export type VoicePhase = 'idle' | 'recording';

export type VoiceRecordingState = {
  phase: VoicePhase;
  isPaused: boolean;
  seconds: number;
  waveformLevels: number[];
  isPlayingPreview: boolean;
  playbackProgress: number;
  canPreview: boolean;
};

export type VoiceRecordingResult = {
  uri: string;
  durationSeconds: number;
  durationLabel: string;
};

const BAR_COUNT = 28;
const DEFAULT_LEVELS = Array.from({ length: BAR_COUNT }, () => 4);

// AAC inside MPEG-4 (.m4a) — Chrome/web and provider playback compatible.
const VOICE_RECORDING_OPTIONS = RecordingPresets.HIGH_QUALITY;

function formatTime(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function normalizeMetering(metering?: number): number {
  if (metering == null || Number.isNaN(metering)) {
    return 4;
  }

  const clamped = Math.min(0, Math.max(-60, metering));
  return Math.round(((clamped + 60) / 60) * 18) + 4;
}

function showRecordingError(message: string) {
  Alert.alert('Voice recording', message);
}

function safePause(player: { pause: () => void }) {
  try {
    player.pause();
  } catch {
    // player may already be released
  }
}

export function useVoiceRecorder() {
  const [phase, setPhase] = useState<VoicePhase>('idle');
  const [isPaused, setIsPaused] = useState(false);
  const [waveformLevels, setWaveformLevels] = useState<number[]>(DEFAULT_LEVELS);
  const levelsRef = useRef<number[]>(DEFAULT_LEVELS);
  const phaseRef = useRef<VoicePhase>('idle');
  const isPausedRef = useRef(false);

  const recorder = useAudioRecorder({
    ...VOICE_RECORDING_OPTIONS,
    isMeteringEnabled: true,
  });
  const recorderState = useAudioRecorderState(recorder, 120);
  const player = useAudioPlayer(null);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  useEffect(() => {
    isPausedRef.current = isPaused;
  }, [isPaused]);

  const recordingSeconds = Math.max(0, Math.floor((recorderState.durationMillis ?? 0) / 1000));
  const seconds = phase === 'recording' ? recordingSeconds : 0;

  useEffect(() => {
    if (phase !== 'recording' || isPaused) {
      return;
    }

    const nextLevel = normalizeMetering(recorderState.metering);
    levelsRef.current = [...levelsRef.current.slice(1), nextLevel];
    setWaveformLevels(levelsRef.current);
  }, [isPaused, phase, recorderState.metering, recorderState.durationMillis]);

  const resetWaveform = useCallback(() => {
    levelsRef.current = DEFAULT_LEVELS;
    setWaveformLevels(DEFAULT_LEVELS);
  }, []);

  const resetSession = useCallback(() => {
    safePause(player);
    resetWaveform();
    setIsPaused(false);
    setPhase('idle');
  }, [player, resetWaveform]);

  const configureRecordingMode = useCallback(async () => {
    await setAudioModeAsync({
      playsInSilentMode: true,
      allowsRecording: true,
      interruptionMode: 'doNotMix',
    });
  }, []);

  const pauseRecording = useCallback(() => {
    safePause(player);
    recorder.pause();
    setIsPaused(true);
  }, [player, recorder]);

  const startRecording = useCallback(async () => {
    if (phaseRef.current !== 'idle') {
      return;
    }

    try {
      const permission = await AudioModule.requestRecordingPermissionsAsync();
      if (!permission.granted) {
        showRecordingError(
          'Microphone permission is required to record voice messages. Enable it in your device settings.',
        );
        return;
      }

      resetWaveform();
      setIsPaused(false);
      setPhase('recording');

      await configureRecordingMode();
      await recorder.prepareToRecordAsync();
      recorder.record();
    } catch (error) {
      console.warn('[useVoiceRecorder] startRecording failed:', error);
      resetSession();
      showRecordingError('Could not start recording. Please try again.');
    }
  }, [configureRecordingMode, recorder, resetSession, resetWaveform]);

  const togglePauseResume = useCallback(async () => {
    if (phaseRef.current !== 'recording') {
      return;
    }

    try {
      if (isPausedRef.current) {
        safePause(player);
        await configureRecordingMode();
        recorder.record();
        setIsPaused(false);
        return;
      }

      pauseRecording();
    } catch (error) {
      console.warn('[useVoiceRecorder] togglePauseResume failed:', error);
      showRecordingError('Could not pause or resume recording. Please try again.');
    }
  }, [configureRecordingMode, pauseRecording, player, recorder]);

  const togglePreviewPlayback = useCallback(async () => {
    // AAC M4A is not finalized until stop(); in-pause preview is unavailable.
  }, []);

  const cancelRecording = useCallback(async () => {
    try {
      if (phaseRef.current === 'recording') {
        await recorder.stop();
      }
    } catch {
      // ignore cleanup errors
    }

    resetSession();
  }, [recorder, resetSession]);

  const finishRecording = useCallback(async (): Promise<VoiceRecordingResult | null> => {
    if (phaseRef.current !== 'recording') {
      return null;
    }

    try {
      safePause(player);
      await recorder.stop();

      const uri = recorder.uri;
      if (!uri) {
        resetSession();
        showRecordingError('Recording was empty. Please try again.');
        return null;
      }

      const durationSeconds = Math.max(1, recordingSeconds);
      const result: VoiceRecordingResult = {
        uri,
        durationSeconds,
        durationLabel: formatTime(durationSeconds),
      };

      resetSession();
      return result;
    } catch (error) {
      console.warn('[useVoiceRecorder] finishRecording failed:', error);
      resetSession();
      showRecordingError('Could not send the recording. Please try again.');
      return null;
    }
  }, [player, recorder, recordingSeconds, resetSession]);

  const state: VoiceRecordingState = {
    phase,
    isPaused,
    seconds,
    waveformLevels,
    isPlayingPreview: false,
    playbackProgress: 0,
    canPreview: false,
  };

  return {
    state,
    isActive: phase !== 'idle',
    startRecording,
    togglePauseResume,
    togglePreviewPlayback,
    cancelRecording,
    finishRecording,
    formatTime,
  };
}
