import type { ChatMessage } from '@/constants/chat';
import type { ApiMessage } from '@/types/message.types';

export type MediaGalleryItem = {
  messageId: string;
  attachmentId?: string;
  createdAt: string;
  kind: 'image' | 'video' | 'pdf' | 'word';
  name: string;
  size: string;
  thumbnail?: string;
  uri?: string;
};

export type MediaGallerySection = {
  title: string;
  items: MediaGalleryItem[];
  sortKey: number;
};

export function isMediaGalleryItem(message: ChatMessage): boolean {
  return (
    message.messageType === 'attachment' &&
    (message.attachment?.type === 'image' || message.attachment?.type === 'video')
  );
}

export function isDocGalleryItem(message: ChatMessage): boolean {
  return (
    message.messageType === 'attachment' &&
    (message.attachment?.type === 'pdf' || message.attachment?.type === 'word')
  );
}

export function toMediaGalleryItem(
  message: ChatMessage,
  createdAt: string,
): MediaGalleryItem | null {
  if (!message.attachment) return null;

  const { type, name, size, thumbnail, uri } = message.attachment;
  if (type !== 'image' && type !== 'video' && type !== 'pdf' && type !== 'word') {
    return null;
  }

  return {
    messageId: message.id,
    attachmentId: message.attachmentId,
    createdAt,
    kind: type,
    name,
    size,
    thumbnail,
    uri,
  };
}

function sectionLabelForDate(iso: string): { title: string; sortKey: number } {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) {
    return { title: 'OLDER', sortKey: 0 };
  }

  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startOfDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const diffDays = Math.floor((startOfToday.getTime() - startOfDate.getTime()) / 86_400_000);

  if (diffDays < 7) {
    return { title: 'RECENT', sortKey: Number.MAX_SAFE_INTEGER };
  }

  if (diffDays < 14) {
    return { title: 'LAST WEEK', sortKey: Number.MAX_SAFE_INTEGER - 1 };
  }

  const month = date.toLocaleDateString('en-US', { month: 'long' }).toUpperCase();
  const year = date.getFullYear();
  const currentYear = now.getFullYear();
  const title = year === currentYear ? month : `${month} ${year}`;

  return { title, sortKey: startOfDate.getTime() };
}

export function groupGalleryItems(items: MediaGalleryItem[]): MediaGallerySection[] {
  const buckets = new Map<string, MediaGallerySection>();

  for (const item of items) {
    const { title, sortKey } = sectionLabelForDate(item.createdAt);
    const existing = buckets.get(title);

    if (existing) {
      existing.items.push(item);
      continue;
    }

    buckets.set(title, { title, items: [item], sortKey });
  }

  return [...buckets.values()]
    .map((section) => ({
      ...section,
      items: [...section.items].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      ),
    }))
    .sort((a, b) => b.sortKey - a.sortKey);
}

export function buildCreatedAtLookup(items: ApiMessage[]): Map<string, string> {
  return new Map(items.map((item) => [item.id, item.created_at]));
}

export function galleryItemsFromMessages(
  messages: ChatMessage[],
  createdAtByMessageId: Map<string, string>,
  tab: 'media' | 'docs',
): MediaGalleryItem[] {
  const predicate = tab === 'media' ? isMediaGalleryItem : isDocGalleryItem;

  return messages
    .filter(predicate)
    .map((message) =>
      toMediaGalleryItem(message, createdAtByMessageId.get(message.id) ?? new Date(0).toISOString()),
    )
    .filter((item): item is MediaGalleryItem => item != null)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}
