import { useLocalSearchParams, useRouter } from 'expo-router';
import { useCallback } from 'react';

import { SEARCH_DATA_ROUTE } from '@/utils/searchNavigation';

export function useDetailBack() {
  const router = useRouter();
  const { fromSearch } = useLocalSearchParams<{ fromSearch?: string | string[] }>();

  return useCallback(() => {
    const value = Array.isArray(fromSearch) ? fromSearch[0] : fromSearch;

    if (value === '1') {
      router.push(SEARCH_DATA_ROUTE);
      return;
    }

    router.back();
  }, [fromSearch, router]);
}
