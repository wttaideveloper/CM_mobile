import { Image } from 'expo-image';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppStatusBar, useStatusBarBackground } from '@/components/AppStatusBar';
import { EmptyState } from '@/components/EmptyState';

import { ChevronLeftIcon } from '@/components/dashboard/DashboardIcons';
import { useDetailBack } from '@/hooks/useDetailBack';
import { useService } from '@/hooks/useServices';
import { useEnterprise } from '@/hooks/useEnterprises';
import type { ServiceDetailItem, ServiceDetailSlot } from '@/types/service.types';
import { formatServicePrice, normalizeDetailSlot } from '@/utils/service.mapper';
import { shadowLg } from '@/utils/shadows';
import { isSmallDevice } from '@/utils/responsive';

const PRIMARY = '#1F5D4E';
const MINT = '#EAF4EC';
const TEXT_MUTED = '#5a7a70';
const TEXT_BLACK = '#111111';
const BORDER = '#E8EDEA';
const SLOT_SELECTED_MUTED = 'rgba(255, 255, 255, 0.6)';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const H_PAD = 20;
const HERO_HEIGHT = Math.round(SCREEN_HEIGHT * 0.28);

type SelectedBooking = {
  dateId: string;
  timeSlot: string;
};

function formatSlotModalTitle(slot: ServiceDetailSlot): string {
  const parsed = new Date(slot.id);
  if (!Number.isNaN(parsed.getTime())) {
    return parsed.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric',
    });
  }

  return `${slot.dayLabel}, ${slot.date}`;
}

function formatTimeSlotLabel(timeSlot: string): string {
  return timeSlot.replace('-', ' – ');
}

type ServiceViewModel = {
  name: string;
  category: string;
  provider: string;
  enterprise: string;
  duration: string;
  price: string;
  sessionType: string;
  format: string;
  description: string;
  image: string;
  availability: ServiceDetailSlot[];
  cancellationPolicy: string;
  maxParticipants: number | null;
};

function mapApiServiceToViewModel(
  service: ServiceDetailItem,
  enterpriseFallback?: string,
): ServiceViewModel {
  const enterprise =
    service.enterpriseName !== 'NA'
      ? service.enterpriseName
      : enterpriseFallback && enterpriseFallback !== 'NA'
        ? enterpriseFallback
        : service.enterpriseName;

  return {
    name: service.name,
    category: service.category,
    provider: service.provider,
    enterprise,
    duration: service.duration,
    price: formatServicePrice(service.price),
    sessionType: service.sessionType,
    format: service.format,
    description: service.description,
    image: service.bannerImage,
    availability: service.availabilitySlots.map((slot) =>
      normalizeDetailSlot(slot, new Date()),
    ),
    cancellationPolicy: service.cancellationPolicy,
    maxParticipants: service.maxParticipants,
  };
}

export function ServiceDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const goBack = useDetailBack();
  const insets = useSafeAreaInsets();
  const [modalDateId, setModalDateId] = useState<string | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<SelectedBooking | null>(null);
  const statusBarFill = useStatusBarBackground();
  const serviceId = Array.isArray(id) ? id[0] : id ?? '';
  const { service: apiService, isLoading, isError } = useService(serviceId, {
    enabled: Boolean(serviceId),
  });
  console.log('apiService', apiService);
  const { enterprise: enterpriseDetail } = useEnterprise(apiService?.enterpriseId ?? '', {
    enabled: Boolean(apiService?.enterpriseId) && apiService?.enterpriseName === 'NA',
  });

  const service = useMemo(() => {
    if (!apiService) {
      return undefined;
    }

    return mapApiServiceToViewModel(apiService, enterpriseDetail?.name);
  }, [apiService, enterpriseDetail?.name]);

  const isLoadingContent = isLoading;
  const showNotFound = !service && !isLoadingContent && isError;

  if (!serviceId) {
    return (
      <View style={styles.screen}>
        <AppStatusBar />
        <EmptyState variant="notFound" entity="service" />
      </View>
    );
  }

  if (showNotFound) {
    return (
      <View style={styles.screen}>
        <AppStatusBar />
        <View style={[styles.statusBarFill, { height: insets.top }]} />
        <EmptyState
          variant="notFound"
          entity="service"
          onAction={goBack}
          actionLabel="Go back"
        />
      </View>
    );
  }

  const weekAvailability = service?.availability ?? [];
  const modalDate = weekAvailability.find((slot) => slot.id === modalDateId) ?? null;
  const modalSlotTimes = modalDate?.slotTimes ?? [];
  const selectedDate =
    weekAvailability.find((slot) => slot.id === selectedBooking?.dateId) ?? null;
  const heroHeight = HERO_HEIGHT + insets.top;

  const openDateModal = (dateId: string) => {
    setModalDateId(dateId);
  };

  const closeDateModal = () => {
    setModalDateId(null);
  };

  const handleTimeSlotSelect = (dateId: string, timeSlot: string) => {
    setSelectedBooking({ dateId, timeSlot });
    setModalDateId(null);
  };

  return (
    <View style={styles.screen}>
      {/* <AppStatusBar /> */}
      <AppStatusBar />

      <View style={[styles.statusBarFill, { height: insets.top, backgroundColor: statusBarFill }]} />

      <View style={styles.body}>
        <View style={[styles.hero, { height: heroHeight }]}>
          {service?.image ? (
            <Image
              source={{ uri: service.image }}
              style={[styles.heroImage, { width: SCREEN_WIDTH, height: heroHeight }]}
              contentFit="cover"
              transition={200}
            />
          ) : (
            <View style={[styles.heroPlaceholder, { width: SCREEN_WIDTH, height: heroHeight }]} />
          )}

          <View style={[styles.heroActions]}>
            <Pressable
              onPress={goBack}
              style={({ pressed }) => [styles.heroBtn, pressed && styles.pressed]}
              hitSlop={8}
            >
              <ChevronLeftIcon size={22} color={PRIMARY} />
            </Pressable>
          </View>
        </View>

        {isLoadingContent ? (
          <View style={styles.loadingContent}>
            <ActivityIndicator color={PRIMARY} size="large" />
          </View>
        ) : service ? (
          <>
            <ScrollView
              style={styles.contentScroll}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ paddingBottom: 16 }}
            >
              <View style={styles.content}>
                <View style={styles.categoryBadge}>
                  <Text style={styles.categoryBadgeText}>{service.category}</Text>
                </View>

                <View style={styles.titleRow}>
                  <Text style={styles.serviceTitle} numberOfLines={2}>
                    {service.name}
                  </Text>
                  <Text style={styles.servicePrice}>{service.price}</Text>
                </View>

                <Text style={styles.providerText}>
                  by {service.provider} · {service.enterprise}
                </Text>

                <View style={styles.specsRow}>
                  <View style={styles.specCard}>
                    <Text style={styles.specValue}>{service.duration}</Text>
                    <Text style={styles.specLabel}>Duration</Text>
                  </View>
                  <View style={styles.specCard}>
                    <Text style={styles.specValue}>{service.sessionType}</Text>
                    <Text style={styles.specLabel}>Type</Text>
                  </View>
                  <View style={styles.specCard}>
                    <Text style={styles.specValue}>{service.format}</Text>
                    <Text style={styles.specLabel}>Format</Text>
                  </View>
                </View>

                <Text style={styles.description}>{service.description}</Text>

                {service.maxParticipants != null ? (
                  <Text style={styles.metaLine}>
                    Up to {service.maxParticipants} participants
                  </Text>
                ) : null}

                {service.cancellationPolicy !== 'NA' ? (
                  <Text style={styles.metaLine}>
                    Cancellation: {service.cancellationPolicy}
                  </Text>
                ) : null}

                <Text style={styles.sectionTitle}>AVAILABLE THIS WEEK</Text>

                {weekAvailability.length === 0 ? (
                  <EmptyState
                    compact
                    title="No availability"
                    description="There are no bookable slots for this week."
                  />
                ) : (
                  <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.slotsScroll}
                  >
                    {weekAvailability.map((slot) => {
                      const isSelected =
                        !slot.isPast && selectedBooking?.dateId === slot.id;

                      return (
                        <Pressable
                          key={slot.id}
                          disabled={slot.isPast}
                          onPress={() => openDateModal(slot.id)}
                          style={[
                            styles.slotCard,
                            slot.isPast && styles.slotCardDisabled,
                            isSelected && styles.slotCardSelected,
                          ]}
                        >
                          <Text
                            style={[
                              styles.slotDay,
                              slot.isPast && styles.slotTextDisabled,
                              isSelected && styles.slotDaySelected,
                            ]}
                          >
                            {slot.dayShort}
                          </Text>
                          <Text
                            style={[
                              styles.slotDate,
                              slot.isPast && styles.slotTextDisabled,
                              isSelected ? styles.slotDateSelected : styles.slotDateUnselected,
                            ]}
                          >
                            {slot.date}
                          </Text>
                          <Text
                            style={[
                              styles.slotCount,
                              slot.isPast && styles.slotTextDisabled,
                              isSelected && styles.slotCountSelected,
                            ]}
                          >
                            {slot.slots ?? 0} slots
                          </Text>
                        </Pressable>
                      );
                    })}
                  </ScrollView>
                )}

                {selectedBooking && selectedDate ? (
                  <Text style={styles.selectedSlotSummary}>
                    Selected: {formatSlotModalTitle(selectedDate)} ·{' '}
                    {formatTimeSlotLabel(selectedBooking.timeSlot)}
                  </Text>
                ) : null}
              </View>
            </ScrollView>

            <Modal
              visible={modalDate != null}
              transparent
              animationType="fade"
              onRequestClose={closeDateModal}
            >
              <Pressable style={styles.modalOverlay} onPress={closeDateModal}>
                <Pressable
                  style={styles.modalCard}
                  onPress={(event) => event.stopPropagation()}
                >
                  <Text style={styles.modalTitle}>
                    {modalDate ? formatSlotModalTitle(modalDate) : ''}
                  </Text>
                  <Text style={styles.modalSubtitle}>Choose a time slot</Text>

                  {modalSlotTimes.length > 0 ? (
                    <ScrollView
                      style={styles.modalSlotsScroll}
                      contentContainerStyle={styles.modalSlotsContent}
                      showsVerticalScrollIndicator={false}
                    >
                      {modalSlotTimes.map((timeSlot) => {
                        const isActive =
                          selectedBooking?.dateId === modalDate?.id &&
                          selectedBooking?.timeSlot === timeSlot;

                        return (
                          <Pressable
                            key={timeSlot}
                            onPress={() => {
                              if (modalDate) {
                                handleTimeSlotSelect(modalDate.id, timeSlot);
                              }
                            }}
                            style={[
                              styles.timeSlotBtn,
                              isActive && styles.timeSlotBtnActive,
                            ]}
                          >
                            <Text
                              style={[
                                styles.timeSlotText,
                                isActive && styles.timeSlotTextActive,
                              ]}
                            >
                              {formatTimeSlotLabel(timeSlot)}
                            </Text>
                          </Pressable>
                        );
                      })}
                    </ScrollView>
                  ) : (
                    <EmptyState
                      compact
                      title="No time slots"
                      description="No time slots are available for this date."
                    />
                  )}

                  <Pressable
                    onPress={closeDateModal}
                    style={({ pressed }) => [
                      styles.modalCloseBtn,
                      pressed && styles.pressed,
                    ]}
                  >
                    <Text style={styles.modalCloseBtnText}>Cancel</Text>
                  </Pressable>
                </Pressable>
              </Pressable>
            </Modal>

            <View
              style={[
                styles.footer,
                { paddingBottom: insets.bottom + 12, paddingTop: 12 },
              ]}
            >
              <Pressable
                style={({ pressed }) => [
                  styles.bookBtn,
                  pressed && styles.pressed,
                  !selectedBooking && styles.bookBtnDisabled,
                ]}
                disabled={!selectedBooking}
                onPress={() => router.push('/(main)/(tabs)/events/appointments')}
              >
                <Text style={styles.bookBtnText}>
                  {selectedBooking
                    ? `Book Session — ${service.price}`
                    : `Select a date & time`}
                </Text>
              </Pressable>
            </View>
          </>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  statusBarFill: {
    backgroundColor: '#FFFFFF',
  },
  body: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  hero: {
    backgroundColor: '#F0F2F1',
  },
  heroImage: {
    backgroundColor: '#F0F2F1',
  },
  heroPlaceholder: {
    backgroundColor: MINT,
  },
  heroActions: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    paddingHorizontal: isSmallDevice ? 12 : 16,
    paddingBottom: isSmallDevice ? 6 : 8,
    marginTop: isSmallDevice ? 6 : 20,
  },
  heroBtn: {
    width: isSmallDevice ? 36 : 40,
    height: isSmallDevice ? 36 : 40,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    ...shadowLg,
  },
  contentScroll: {
    flex: 1,
  },
  content: {
    paddingHorizontal: H_PAD,
    paddingTop: isSmallDevice ? 16 : 20,
  },
  categoryBadge: {
    alignSelf: 'flex-start',
    backgroundColor: MINT,
    paddingHorizontal: isSmallDevice ? 8 : 10,
    paddingVertical: isSmallDevice ? 3 :  4,
    borderRadius: 12,
    marginBottom: isSmallDevice ? 8 : 10,
  },
  categoryBadgeText: {
    fontSize: isSmallDevice ? 11 : 12,
    lineHeight: 16,
    fontWeight: '600',
    color: PRIMARY,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: isSmallDevice ? 3 : 4,
  },
  serviceTitle: {
    flex: 1,
    fontSize: isSmallDevice ? 20 : 22,
    lineHeight: 28,
    fontWeight: '900',
    color: TEXT_BLACK,
  },
  servicePrice: {
    fontSize: isSmallDevice ? 20 : 22,
    lineHeight: 28,
    fontWeight: '700',
    color: PRIMARY,
    flexShrink: 0,
  },
  providerText: {
    fontSize: isSmallDevice ? 14 : 15,
    lineHeight: 22,
    fontWeight: '400',
    color: TEXT_MUTED,
    marginBottom: isSmallDevice ? 16 : 20,
  },
  specsRow: {
    flexDirection: 'row',
    gap: isSmallDevice ? 8 : 10,
    marginBottom: isSmallDevice ? 16 : 20,
  },
  specCard: {
    flex: 1,
    minWidth: 0,
    backgroundColor: '#F7FAF8',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: BORDER,
    paddingVertical: isSmallDevice ? 8 : 10,
    paddingHorizontal: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  specValue: {
    fontSize: isSmallDevice ? 14 : 16,
    lineHeight: 22,
    fontWeight: '700',
    color: TEXT_BLACK,
    marginBottom: isSmallDevice ? 1 : 2,
    textAlign: 'center',
  },
  specLabel: {
    fontSize: isSmallDevice ? 11 : 12,
    lineHeight: 16,
    fontWeight: '500',
    color: TEXT_MUTED,
    textAlign: 'center',
  },
  description: {
    fontSize: isSmallDevice ? 14 : 15,
    lineHeight: 24,
    fontWeight: '400',
    color: TEXT_MUTED,
    marginBottom: isSmallDevice ? 8 : 12,
  },
  metaLine: {
    fontSize: isSmallDevice ? 13 : 14,
    lineHeight: 20,
    fontWeight: '500',
    color: TEXT_MUTED,
    marginBottom: isSmallDevice ? 6 : 8,
  },
  sectionTitle: {
    fontSize: isSmallDevice ? 12 : 13,
    lineHeight: 18,
    fontWeight: '700',
    color: TEXT_BLACK,
    letterSpacing: 0.6,
    marginBottom: isSmallDevice ? 12 : 14,
    marginTop: isSmallDevice ? 8 : 12,
  },
  emptySlotsText: {
    fontSize: isSmallDevice ? 13 : 14,
    lineHeight: 20,
    fontWeight: '500',
    color: TEXT_MUTED,
    marginBottom: isSmallDevice ? 6 :   8,
  },
  slotsScroll: {
    gap: isSmallDevice ? 8 : 10,
    paddingRight: H_PAD,
  },
  slotCard: {
    width: isSmallDevice ? 60 : 68,
    paddingVertical: isSmallDevice ? 6 : 8,
    paddingHorizontal: 8,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: BORDER,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  slotCardSelected: {
    backgroundColor: PRIMARY,
    borderColor: PRIMARY,
  },
  slotCardDisabled: {
    opacity: 0.5,
    backgroundColor: '#F3F4F6',
    borderColor: '#E5E7EB',
  },
  slotTextDisabled: {
    color: '#9CA3AF',
  },
  slotDay: {
    fontSize: isSmallDevice ? 11 : 12,
    lineHeight: 16,
    fontWeight: '600',
    color: PRIMARY,
    marginBottom: 2,
  },
  slotDaySelected: {
    color: SLOT_SELECTED_MUTED,
    fontWeight: '700',
  },
  slotDate: {
    fontSize: isSmallDevice ? 16 : 18,
    lineHeight: 26,
    fontWeight: '700',
    marginBottom: 2,
  },
  slotDateUnselected: {
    color: TEXT_BLACK,
  },
  slotDateSelected: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  slotCount: {
    fontSize: isSmallDevice ? 10 : 11,
    lineHeight: 14,
    fontWeight: '500',
    color: TEXT_MUTED,
  },
  slotCountSelected: {
    color: SLOT_SELECTED_MUTED,
    fontWeight: '700',
  },
  selectedSlotSummary: {
    marginTop: isSmallDevice ? 10 : 12,
    fontSize: isSmallDevice ? 13 : 14,
    lineHeight: 20,
    fontWeight: '600',
    color: PRIMARY,
    marginBottom: isSmallDevice ? 10 : 14,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.45)',
    justifyContent: 'flex-end',
  },
  modalCard: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: H_PAD,
    paddingTop: isSmallDevice ? 20 : 24,
    paddingBottom: isSmallDevice ? 24 : 28,
    maxHeight: '70%',
  },
  modalTitle: {
    fontSize: isSmallDevice ? 18 : 20,
    lineHeight: 28,
    fontWeight: '800',
    color: TEXT_BLACK,
    marginBottom: 4,
  },
  modalSubtitle: {
    fontSize: isSmallDevice ? 13 : 14,
    lineHeight: 20,
    fontWeight: '500',
    color: TEXT_MUTED,
    marginBottom: isSmallDevice ? 14 : 16,
  },
  modalSlotsScroll: {
    maxHeight: 280,
  },
  modalSlotsContent: {
    gap: isSmallDevice ? 8 : 10,
    paddingBottom: 8,
  },
  timeSlotBtn: {
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 14,
    paddingVertical: isSmallDevice ? 12 : 14,
    paddingHorizontal: 16,
    backgroundColor: '#F7FAF8',
    alignItems: 'center',
  },
  timeSlotBtnActive: {
    backgroundColor: PRIMARY,
    borderColor: PRIMARY,
  },
  timeSlotText: {
    fontSize: isSmallDevice ? 14 : 15,
    lineHeight: 20,
    fontWeight: '700',
    color: TEXT_BLACK,
  },
  timeSlotTextActive: {
    color: '#FFFFFF',
  },
  modalEmptyText: {
    fontSize: isSmallDevice ? 14 : 15,
    lineHeight: 22,
    fontWeight: '500',
    color: TEXT_MUTED,
    marginBottom: 16,
  },
  modalCloseBtn: {
    marginTop: isSmallDevice ? 12 : 16,
    height: isSmallDevice ? 44 : 48,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: BORDER,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalCloseBtnText: {
    fontSize: isSmallDevice ? 14 : 15,
    fontWeight: '700',
    color: TEXT_MUTED,
  },
  footer: {
    paddingHorizontal: H_PAD,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: BORDER,
  },
  bookBtn: {
    height: isSmallDevice ? 40 : 52,
    borderRadius: 16,
    backgroundColor: PRIMARY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bookBtnDisabled: {
    opacity: 0.55,
  },
  bookBtnText: {
    fontSize: isSmallDevice ? 14 : 15,
    lineHeight: 20,
    fontWeight: '900',
    color: '#FFFFFF',
  },
  pressed: {
    opacity: 0.9,
  },
  loadingContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
  },
  loadingState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    padding: 24,
  },
  fallbackBtn: {
    marginTop: 16,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: PRIMARY,
  },
  fallbackBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  errorText: {
    fontSize: isSmallDevice ? 14 : 16,
    color: TEXT_MUTED,
  },
});
