import { useLocalSearchParams, useRouter } from 'expo-router';
import { AppStatusBar, useStatusBarBackground } from '@/components/AppStatusBar';
import { EmptyState } from '@/components/EmptyState';
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQueryClient } from '@tanstack/react-query';

import { SearchIcon, WrenchIcon } from '@/components/dashboard/DashboardIcons';
import { SERVICE_CATEGORIES } from '@/constants/services';
import { useEnterprises } from '@/hooks/useEnterprises';
import { serviceKeys, useInfiniteServices } from '@/hooks/useServices';
import { SERVICE_FILTER_PAGE_SIZE } from '@/services/service.service';
import type { ServiceListItem, ServiceListQuery } from '@/types/service.types';
import { formatServicePrice } from '@/utils/service.mapper';
import { detailHref } from '@/utils/searchNavigation';
import { shadowSm } from '@/utils/shadows';
import { isSmallDevice } from '@/utils/responsive';
import { serviceService } from '@/services/service.service';

const PRIMARY = '#1F5D4E';
const MINT = '#EAF4EC';
const BODY_BG = '#F5F7F5';
const TEXT_MUTED = '#5a7a70';
const TEXT_BLACK = '#111111';
const BORDER = '#E8EDEA';
const SEARCH_BORDER = '#E0E7E1';
const H_PAD = 20;
const SEARCH_DEBOUNCE_MS = 400;

export function ServiceCard({
  service,
  enterpriseNameById,
  fromSearch,
}: {
  service: ServiceListItem;
  enterpriseNameById: Record<string, string>;
  fromSearch?: boolean;
}) {
  const router = useRouter();
  const queryClient = useQueryClient();
  const enterpriseName =
    service.enterpriseName !== 'NA'
      ? service.enterpriseName
      : enterpriseNameById[service.enterpriseId] ?? 'NA';

  const openDetail = () => {
    void queryClient.prefetchQuery({
      queryKey: serviceKeys.detail(service.id),
      queryFn: () => serviceService.getById(service.id),
    });
    router.push(detailHref('/(main)/service', service.id, fromSearch));
  };

  return (
    <Pressable
      onPress={openDetail}
      style={({ pressed }) => [styles.serviceCard, pressed && styles.cardPressed]}
    >
      <View style={styles.iconBox}>
        <WrenchIcon size={22} color={PRIMARY} />
      </View>

      <View style={styles.cardContent}>
        <View style={styles.categoryBadge}>
          <Text style={styles.categoryBadgeText}>{service.category}</Text>
        </View>
        <Text style={styles.serviceName} numberOfLines={2}>
          {service.name}
        </Text>
        <Text style={styles.serviceMeta} numberOfLines={1}>
          {service.provider} · {enterpriseName}
        </Text>
      </View>

      <View style={styles.priceBlock}>
        <Text style={styles.servicePrice}>{formatServicePrice(service.price)}</Text>
        <Text style={styles.serviceUnit}>{service.unit}</Text>
      </View>
    </Pressable>
  );
}

export function ServicesScreen() {
  const insets = useSafeAreaInsets();
  const statusBarFill = useStatusBarBackground();
  const listRef = useRef<FlatList<ServiceListItem>>(null);
  const { enterpriseId: rawEnterpriseId } = useLocalSearchParams<{
    enterpriseId?: string | string[];
  }>();
  const enterpriseId = Array.isArray(rawEnterpriseId)
    ? rawEnterpriseId[0]
    : rawEnterpriseId;

  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search.trim());
    }, SEARCH_DEBOUNCE_MS);

    return () => clearTimeout(timer);
  }, [search]);

  const apiQuery = useMemo((): ServiceListQuery => {
    const hasSearch = debouncedSearch.length > 0;
    const hasCategory = activeCategory !== 'All';
    const hasEnterprise = Boolean(enterpriseId);
    const isFiltered = hasSearch || hasCategory || hasEnterprise;

    const query: ServiceListQuery = {
      page_size: isFiltered ? SERVICE_FILTER_PAGE_SIZE : undefined,
    };

    if (hasEnterprise && enterpriseId) {
      query.enterprise_id = enterpriseId;
    }

    if (hasSearch) {
      query.search = debouncedSearch;
    }

    if (hasCategory) {
      query.category = activeCategory;
    }

    return query;
  }, [activeCategory, debouncedSearch, enterpriseId]);

  const {
    data,
    isLoading,
    isFetching,
    isError,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
    refetch,
    isRefetching,
  } = useInfiniteServices(apiQuery);

  const services = useMemo(
    () => data?.pages.flatMap((page) => page.items) ?? [],
    [data],
  );

  const totalCount = data?.pages[0]?.pagination.total ?? services.length;
  const isFiltering = isFetching && !isFetchingNextPage;

  const { data: enterprises = [] } = useEnterprises();

  const enterpriseNameById = useMemo(
    () =>
      Object.fromEntries(
        enterprises.map((enterprise) => [enterprise.id, enterprise.name]),
      ),
    [enterprises],
  );

  useEffect(() => {
    listRef.current?.scrollToOffset({ offset: 0, animated: false });
  }, [apiQuery.search, apiQuery.category, apiQuery.enterprise_id]);

  const handleCategoryPress = (category: string) => {
    setActiveCategory((current) => (current === category ? 'All' : category));
  };

  const handleLoadMore = () => {
    if (hasNextPage && !isFetchingNextPage) {
      void fetchNextPage();
    }
  };

  return (
    <View style={styles.screen}>
      <AppStatusBar />

      <View style={[styles.statusBarFill, { height: insets.top, backgroundColor: statusBarFill }]} />

      <View style={[styles.topSection, { paddingTop: 12 }]}>
        <Text style={styles.title}>Services</Text>

        <View style={styles.searchWrap}>
          <SearchIcon size={18} color={TEXT_MUTED} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search services..."
            placeholderTextColor={TEXT_MUTED}
            value={search}
            onChangeText={setSearch}
            returnKeyType="search"
            autoCorrect={false}
            onSubmitEditing={() => setDebouncedSearch(search.trim())}
          />
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesScroll}
        >
          {SERVICE_CATEGORIES.map((category) => {
            const isActive = activeCategory === category;

            return (
              <Pressable
                key={category}
                onPress={() => handleCategoryPress(category)}
                style={[
                  styles.categoryChip,
                  isActive && styles.categoryChipActive,
                ]}
              >
                <Text
                  style={[
                    styles.categoryChipText,
                    isActive && styles.categoryChipTextActive,
                  ]}
                >
                  {category}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>

        <Text style={styles.resultCount}>{totalCount} services found</Text>
      </View>

      <FlatList
        ref={listRef}
        data={services}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ServiceCard
            service={item}
            enterpriseNameById={enterpriseNameById}
          />
        )}
        style={styles.listScroll}
        contentContainerStyle={[
          styles.listContent,
          services.length === 0 && styles.listContentEmpty,
          { paddingBottom: insets.bottom + 24 },
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.35}
        refreshing={isRefetching && !isFetchingNextPage}
        onRefresh={() => {
          void refetch();
        }}
        ItemSeparatorComponent={() => <View style={styles.listSeparator} />}
        ListFooterComponent={
          isFetchingNextPage || (isFiltering && services.length > 0) ? (
            <View style={styles.footerLoader}>
              <ActivityIndicator color={PRIMARY} />
            </View>
          ) : null
        }
        ListEmptyComponent={
          isLoading || isFiltering ? (
            <View style={styles.emptyState}>
              <ActivityIndicator color={PRIMARY} size="large" />
            </View>
          ) : isError ? (
            <EmptyState variant="error" entity="services" onAction={() => void refetch()} />
          ) : (
            <EmptyState entity="services" />
          )
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: BODY_BG,
  },
  statusBarFill: {
    backgroundColor: BODY_BG,
  },
  topSection: {
    backgroundColor: BODY_BG,
    paddingHorizontal: isSmallDevice ? 16 : H_PAD,
    marginBottom: 0,
  },
  title: {
    fontSize: isSmallDevice ? 18 : 24,
    lineHeight: 32,
    fontWeight: '700',
    color: TEXT_BLACK,
    marginBottom: 10,
  },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F7F3',
    borderRadius: isSmallDevice ? 16 : 18,
    borderWidth: 1,
    borderColor: SEARCH_BORDER,
    paddingHorizontal: isSmallDevice ? 12 : 16,
    height: isSmallDevice ? 40 : 48,
    marginBottom: isSmallDevice ? 12 : 16,
    gap: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: isSmallDevice ? 14 : 15,
    lineHeight: 20,
    color: TEXT_BLACK,
    paddingVertical: 0,
  },
  categoriesScroll: {
    gap: isSmallDevice ? 6 : 8,
    paddingBottom: isSmallDevice ? 8 : 12,
  },
  categoryChip: {
    paddingHorizontal: isSmallDevice ? 16 : 20,
    paddingVertical: isSmallDevice ? 3 : 4,
    borderRadius: 20,
    backgroundColor: MINT,
  },
  categoryChipActive: {
    backgroundColor: PRIMARY,
  },
  categoryChipText: {
    fontSize: isSmallDevice ? 13 : 14,
    lineHeight: 20,
    fontWeight: '600',
    color: PRIMARY,
  },
  categoryChipTextActive: {
    color: '#FFFFFF',
  },
  resultCount: {
    fontSize: isSmallDevice ? 12 : 13,
    fontWeight: '600',
    color: TEXT_MUTED,
    marginBottom: isSmallDevice ? 6 : 8,
  },
  listScroll: {
    flex: 1,
    backgroundColor: BODY_BG,
  },
  listContent: {
    paddingHorizontal: H_PAD,
  },
  listSeparator: {
    height: 12,
  },
  listContentEmpty: {
    flexGrow: 1,
  },
  footerLoader: {
    paddingVertical: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyState: {
    paddingVertical: isSmallDevice ? 36 : 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  serviceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: BORDER,
    padding: isSmallDevice ? 16 : 20,
    gap: 12,
    ...shadowSm,
  },
  iconBox: {
    width: isSmallDevice ? 48 : 52,
    height: isSmallDevice ? 48 : 52,
    borderRadius: 16,
    backgroundColor: MINT,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  categoryBadge: {
    alignSelf: 'flex-start',
    backgroundColor: MINT,
    paddingHorizontal: isSmallDevice ? 8 : 10,
    paddingVertical: isSmallDevice ? 3 : 4,
    borderRadius: 12,
    marginBottom: isSmallDevice ? 4 : 6,
  },
  categoryBadgeText: {
    fontSize: isSmallDevice ? 11 : 12,
    lineHeight: 16,
    fontWeight: '600',
    color: PRIMARY,
  },
  serviceName: {
    fontSize: isSmallDevice ? 14 : 15,
    lineHeight: 20,
    fontWeight: '700',
    color: TEXT_BLACK,
    marginBottom: isSmallDevice ? 3 : 4,
  },
  serviceMeta: {
    fontSize: isSmallDevice ? 12 : 13,
    lineHeight: 18,
    fontWeight: '400',
    color: TEXT_MUTED,
  },
  priceBlock: {
    alignItems: 'flex-end',
    flexShrink: 0,
    alignSelf: 'center',
  },
  servicePrice: {
    fontSize: isSmallDevice ? 16 : 18,
    lineHeight: 24,
    fontWeight: '700',
    color: PRIMARY,
  },
  serviceUnit: {
    fontSize: isSmallDevice ? 11 : 12,
    lineHeight: 16,
    fontWeight: '500',
    color: TEXT_MUTED,
    marginTop: isSmallDevice ? 1 : 2,
  },
  cardPressed: {
    opacity: 0.92,
  },
});
