import type { Href } from 'expo-router';

export const SEARCH_DATA_ROUTE = '/(main)/search-data' as const;
export const FROM_SEARCH_PARAM = 'fromSearch' as const;

type DetailParams = Record<string, string>;

export function withFromSearch(params?: DetailParams): DetailParams {
  if (!params) {
    return { [FROM_SEARCH_PARAM]: '1' };
  }

  return { ...params, [FROM_SEARCH_PARAM]: '1' };
}

export function detailHref(
  pathname: string,
  id: string,
  fromSearch?: boolean,
  params?: DetailParams,
): Href {
  const mergedParams = {
    ...params,
    ...(fromSearch ? { [FROM_SEARCH_PARAM]: '1' } : {}),
  };

  if (Object.keys(mergedParams).length === 0) {
    return `${pathname}/${id}` as Href;
  }

  const searchParams = new URLSearchParams(mergedParams);
  return `${pathname}/${id}?${searchParams.toString()}` as Href;
}
