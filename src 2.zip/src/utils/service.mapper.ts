import type {
  ServiceApiResponse,
  ServiceAvailabilityDay,
  ServiceDetailItem,
  ServiceDetailSlot,
  ServiceListItem,
} from '@/types/service.types';

import { getFullWeekSlots } from '@/utils/weekAvailability';

const DEFAULT_BANNER_IMAGE =
  'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=375&h=350&fit=crop';

function textOrNa(value?: string | null): string {
  if (value == null || value.trim() === '') {
    return 'NA';
  }
  return value.trim();
}

function formatDuration(minutes: number): string {
  if (!minutes) {
    return 'NA';
  }

  return `${minutes} min`;
}

export function formatServiceLabel(value?: string | null): string {
  if (value == null || value.trim() === '') {
    return 'NA';
  }

  return value
    .trim()
    .split('_')
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

function pickTrainerName(item: ServiceApiResponse): string {
  return textOrNa(
    item.trainer_name ?? item.provider_name ?? item.instructor_name,
  );
}

function pickSessionType(item: ServiceApiResponse): string {
  return textOrNa(item.type ?? item.service_type ?? item.service_category);
}

function pickFormat(item: ServiceApiResponse): string {
  const raw = item.format ?? item.delivery_format;
  if (raw == null || raw.trim() === '') {
    return 'NA';
  }
  return formatServiceLabel(raw);
}

function pickBannerImage(item: ServiceApiResponse): string {
  if (item.banner_image?.trim()) {
    return item.banner_image.trim();
  }
  return DEFAULT_BANNER_IMAGE;
}

function toDayShort(day: string): string {
  const trimmed = day.trim();
  if (trimmed.length <= 3) {
    return trimmed;
  }
  return trimmed.slice(0, 3);
}

export function normalizeDetailSlot(
  slot: Omit<ServiceDetailSlot, 'isPast'>,
  referenceDate = new Date(),
): ServiceDetailSlot {
  const slotTimes = Array.isArray(slot.slotTimes) ? slot.slotTimes : [];
  const today = new Date(referenceDate);
  today.setHours(0, 0, 0, 0);

  let isPast = false;
  const slotDate = new Date(slot.id);
  if (!Number.isNaN(slotDate.getTime())) {
    slotDate.setHours(0, 0, 0, 0);
    isPast = slotDate < today;
  }

  return {
    id: slot.id,
    dayShort: slot.dayShort ?? '',
    dayLabel: slot.dayLabel ?? slot.dayShort ?? '',
    date: slot.date ?? 0,
    slots: slot.slots ?? slotTimes.length,
    slotTimes,
    isPast,
  };
}

function mapAvailabilityDay(item: ServiceAvailabilityDay): Omit<ServiceDetailSlot, 'isPast'> {
  const parsedDate = new Date(item.date);

  return {
    id: item.date,
    dayShort: toDayShort(item.day),
    dayLabel: item.day.trim(),
    date: Number.isNaN(parsedDate.getTime())
      ? 0
      : parsedDate.getDate(),
    slots: item.slots?.length ?? 0,
    slotTimes: item.slots ?? [],
  };
}

export function mapApiAvailabilityToSlots(
  availability?: ServiceAvailabilityDay[] | null,
  referenceDate = new Date(),
): ServiceDetailSlot[] {
  const today = new Date(referenceDate);
  today.setHours(0, 0, 0, 0);

  const weekStart = new Date(today);
  weekStart.setDate(today.getDate() - today.getDay());
  weekStart.setHours(0, 0, 0, 0);

  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6);
  weekEnd.setHours(23, 59, 59, 999);

  const isInCurrentWeek = (slot: ServiceDetailSlot) => {
    const slotDate = new Date(slot.id);
    if (Number.isNaN(slotDate.getTime())) {
      return true;
    }
    slotDate.setHours(0, 0, 0, 0);
    return slotDate >= weekStart && slotDate <= weekEnd;
  };

  if (!availability?.length) {
    return getFullWeekSlots(referenceDate).map((slot) =>
      normalizeDetailSlot(
        {
          id: slot.id,
          dayShort: slot.dayShort,
          dayLabel: slot.dayShort,
          date: slot.date,
          slots: slot.slots,
          slotTimes: [],
        },
        referenceDate,
      ),
    );
  }

  const weekSlots = availability
    .map(mapAvailabilityDay)
    .map((slot) => normalizeDetailSlot(slot, referenceDate))
    .filter(isInCurrentWeek)
    .sort((a, b) => {
      const aTime = new Date(a.id).getTime();
      const bTime = new Date(b.id).getTime();
      if (Number.isNaN(aTime) || Number.isNaN(bTime)) {
        return 0;
      }
      return aTime - bTime;
    });

  if (weekSlots.length > 0) {
    return weekSlots;
  }

  return availability
    .map(mapAvailabilityDay)
    .map((slot) => normalizeDetailSlot(slot, referenceDate));
}

export function mapServiceApiToListItem(item: ServiceApiResponse): ServiceListItem {
  const durationMinutes = item.duration ?? item.duration_minutes ?? 0;
  const price = item.service_price ?? item.price ?? 0;
  const isActive =
    item.service_status ??
    (typeof item.status === 'string' ? item.status.toLowerCase() === 'active' : false);

  return {
    id: item.id,
    enterpriseId: item.enterprise_id,
    enterpriseName: textOrNa(item.enterprise_name),
    name: textOrNa(item.service_name),
    description: textOrNa(item.service_description ?? item.description),
    category: textOrNa(item.service_category ?? item.category),
    price,
    duration: formatDuration(durationMinutes),
    provider: pickTrainerName(item),
    unit: '/session',
    isAvailable: item.availability_status ?? true,
    isActive: Boolean(isActive),
  };
}

export function mapServiceApiToDetailItem(item: ServiceApiResponse): ServiceDetailItem {
  const base = mapServiceApiToListItem(item);

  return {
    ...base,
    enterpriseName: textOrNa(item.enterprise_name),
    sessionType: pickSessionType(item),
    format: pickFormat(item),
    bannerImage: pickBannerImage(item),
    availabilitySlots: mapApiAvailabilityToSlots(item.availability),
    cancellationPolicy: textOrNa(item.cancellation_policy),
    maxParticipants: item.max_participants ?? null,
    currency: item.currency?.trim() || 'USD',
  };
}

export function mapServicesApiResponse(
  items: ServiceApiResponse[],
): ServiceListItem[] {
  return items.map(mapServiceApiToListItem);
}

export function formatServicePrice(price: number): string {
  if (!price) {
    return '$0';
  }

  return `$${price.toLocaleString('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  })}`;
}
