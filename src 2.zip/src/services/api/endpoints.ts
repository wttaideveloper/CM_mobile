export const ENDPOINTS = {
  AUTH: {
    LOGIN: '/auth/login',
    REFRESH_TOKEN: '/auth/refresh-token',
    LOGOUT: '/auth/logout',
  },

  ENTERPRISES: {
    GET_ALL: '/api/v1/enterprises/',
    GET_BY_ID: (id: string) => `/api/v1/enterprises/${id}`,
  },

  PRODUCTS: {
    GET_ALL: '/api/v1/products/',
    GET_BY_ID: (id: string) => `/api/v1/products/${id}`,
  },

  SERVICES: {
    GET_ALL: '/api/v1/services/',
    GET_BY_ID: (id: string) => `/api/v1/services/${id}`,
  },

  SEARCH: {
    ENTERPRISES: '/api/v1/search/enterprises',
    PRODUCTS: '/api/v1/search/products',
    SERVICES: '/api/v1/search/services',
  },
} as const;
