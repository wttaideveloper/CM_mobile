import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import type { ChatMessage } from '@/constants/chat';
import { isSmallDevice } from '@/utils/responsive';
import { shadowSm } from '@/utils/shadows';

const PRIMARY = '#1F5D4E';
const PAGE_BG = '#FFFFFF';
const TEXT_MUTED = '#9CA3AF';
const TEXT_DESC = '#6B7280';
const TEXT_BLACK = '#111111';
const BORDER = '#E8EDEA';
const BUBBLE_MAX = '78%';

const GROUP_SENDER_COLORS: Record<string, string> = {
  'Alex Martinez': '#1F5D4E',
  'Dr. Sarah Kim': '#7C3AED',
  'Sarah Chen': '#0D9488',
  'Dr. James Wilson': '#C2410C',
  'Maria Lopez': '#2563EB',
};

const GROUP_SENDER_COLOR_FALLBACKS = ['#1F5D4E', '#7C3AED', '#0D9488', '#C2410C', '#2563EB'];

function getGroupSenderColor(name: string): string {
  if (GROUP_SENDER_COLORS[name]) {
    return GROUP_SENDER_COLORS[name];
  }

  let hash = 0;
  for (let i = 0; i < name.length; i += 1) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }

  return GROUP_SENDER_COLOR_FALLBACKS[Math.abs(hash) % GROUP_SENDER_COLOR_FALLBACKS.length];
}

const ATTACHMENT_ICONS: Record<string, string> = {
  image: '🖼️',
  pdf: '📄',
  word: '📝',
  video: '🎬',
  audio: '🎵',
};

function ReadReceipt({ status }: { status?: ChatMessage['status'] }) {
  if (!status) return null;

  if (status === 'sent') {
    return <Ionicons name="checkmark" size={14} color="rgba(255,255,255,0.75)" />;
  }

  const tickColor = status === 'read' ? '#53BDEB' : 'rgba(255,255,255,0.85)';
  return <Ionicons name="checkmark-done" size={15} color={tickColor} />;
}

function Reactions({
  reactions,
  isUser,
}: {
  reactions: ChatMessage['reactions'];
  isUser: boolean;
}) {
  if (!reactions?.length) return null;

  const label = reactions
    .map((r) => (r.count > 1 ? `${r.emoji} ${r.count}` : r.emoji))
    .join(' ');

  return (
    <View style={[styles.reactionsBadge, isUser ? styles.reactionsBadgeUser : styles.reactionsBadgeProvider]}>
      <Text style={styles.reactionsEmoji}>{label}</Text>
    </View>
  );
}

function AttachmentCard({ message, isUser }: { message: ChatMessage; isUser: boolean }) {
  const att = message.attachment!;
  const isMedia = att.type === 'image' || att.type === 'video';

  return (
    <View style={[styles.attachCard, isUser && styles.attachCardUser]}>
      {isMedia && att.thumbnail ? (
        <Image source={{ uri: att.thumbnail }} style={styles.attachThumb} contentFit="cover" />
      ) : (
        <View style={styles.attachIconBox}>
          <Text style={styles.attachEmoji}>{ATTACHMENT_ICONS[att.type]}</Text>
        </View>
      )}
      <View style={styles.attachInfo}>
        <Text style={[styles.attachName, isUser && styles.attachNameUser]} numberOfLines={1}>
          {att.name}
        </Text>
        <Text style={[styles.attachMeta, isUser && styles.attachMetaUser]}>
          {att.size}{att.duration ? ` · ${att.duration}` : ''} · {att.storage}
        </Text>
      </View>
      {att.type === 'video' ? <Text style={styles.playBtn}>▶</Text> : null}
      {att.type === 'audio' ? <Text style={styles.playBtn}>🔊</Text> : null}
    </View>
  );
}

function VoiceBubble({ message, isUser }: { message: ChatMessage; isUser: boolean }) {
  return (
    <View>
      <View style={[styles.voiceRow, isUser && styles.voiceRowUser]}>
        <Text style={styles.voicePlay}>▶</Text>
        <View style={styles.waveform}>
          {[3, 6, 4, 8, 5, 9, 4, 7, 3, 8, 5, 6].map((h, i) => (
            <View key={i} style={[styles.waveBar, { height: h * 2 }, isUser && styles.waveBarUser]} />
          ))}
        </View>
        <Text style={[styles.voiceDuration, isUser && styles.voiceDurationUser]}>
          {message.voice?.duration}
        </Text>
      </View>
      {message.voice?.transcript ? (
        <View style={styles.transcriptBox}>
          <Text style={styles.transcriptLabel}>Speech-to-text</Text>
          <Text style={styles.transcriptText}>{message.voice.transcript}</Text>
        </View>
      ) : null}
    </View>
  );
}

function MarkdownText({ text }: { text: string }) {
  const lines = text.split('\n');
  return (
    <View style={styles.markdownBlock}>
      {lines.map((line, i) => {
        const isBold = line.startsWith('**') && line.endsWith('**');
        const isBullet = line.startsWith('•');
        const content = isBold ? line.slice(2, -2) : line;
        return (
          <Text
            key={i}
            style={[styles.markdownLine, isBold && styles.markdownBold, isBullet && styles.markdownBullet]}
          >
            {content}
          </Text>
        );
      })}
    </View>
  );
}

function MessageActions() {
  return (
    <View style={styles.actionsRow}>
      <Pressable style={styles.actionChip}><Text style={styles.actionText}>Edit</Text></Pressable>
      <Pressable style={styles.actionChip}><Text style={styles.actionText}>Delete</Text></Pressable>
      <Pressable style={styles.actionChip}><Text style={styles.actionText}>History</Text></Pressable>
    </View>
  );
}

export function ChatMessageItem({
  message,
  isGroup = false,
}: {
  message: ChatMessage;
  isGroup?: boolean;
}) {
  if (message.sender === 'system') {
    return (
      <View style={styles.systemRow}>
        <View style={[styles.systemBubble, message.isArchived && styles.archivedBubble]}>
          <Text style={styles.systemText}>{message.text}</Text>
        </View>
      </View>
    );
  }

  const isUser = message.sender === 'user';
  const showSenderName = isGroup && !isUser && !!message.senderName;

  if (message.messageType === 'deleted') {
    return (
      <View style={isUser ? styles.userRow : styles.providerRow}>
        <View style={styles.deletedBubble}>
          <Text style={styles.deletedText}>🚫 {message.text}</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={isUser ? styles.userRow : styles.providerRow}>
      <View style={styles.bubbleWrap}>
        {showSenderName ? (
          <Text
            style={[styles.senderName, { color: getGroupSenderColor(message.senderName!) }]}
            numberOfLines={1}
          >
            {message.senderName}
          </Text>
        ) : null}
        <Pressable style={[styles.bubble, isUser ? styles.userBubble : styles.providerBubble]}>
          {message.messageType === 'attachment' ? (
            <>
              {message.text ? (
                <Text style={[styles.bubbleText, isUser && styles.userText]}>{message.text}</Text>
              ) : null}
              <AttachmentCard message={message} isUser={isUser} />
            </>
          ) : null}

          {message.messageType === 'voice' ? <VoiceBubble message={message} isUser={isUser} /> : null}

          {message.messageType === 'markdown' && message.text ? (
            <MarkdownText text={message.text} />
          ) : null}

          {(message.messageType === 'text' || !message.messageType) && message.text ? (
            <Text style={[styles.bubbleText, isUser && styles.userText]}>{message.text}</Text>
          ) : null}

          <View style={[styles.bubbleFooter, isUser && styles.bubbleFooterUser]}>
            <Text style={[styles.bubbleTime, isUser && styles.userTime]}>{message.timestamp}</Text>
            {message.isEdited ? (
              <Text style={[styles.editedLabel, isUser && styles.userTime]}>edited</Text>
            ) : null}
            {isUser ? <ReadReceipt status={message.status} /> : null}
          </View>

          {message.isEdited ? <MessageActions /> : null}
        </Pressable>
        <Reactions reactions={message.reactions} isUser={isUser} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  systemRow: { alignItems: 'center', marginVertical: 4 },
  systemBubble: {
    backgroundColor: '#E5E7EB',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 6,
    maxWidth: '92%',
  },
  archivedBubble: { backgroundColor: '#FEF3C7' },
  systemText: { fontSize: 11, fontWeight: '600', color: TEXT_DESC, textAlign: 'center' },
  providerRow: { alignItems: 'flex-start', marginRight: '18%' },
  userRow: { alignItems: 'flex-end', marginLeft: '18%' },
  bubbleWrap: { position: 'relative', maxWidth: BUBBLE_MAX, marginBottom: 10 },
  senderName: {
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 4,
    marginLeft: 4,
  },
  bubble: { borderRadius: 16, paddingHorizontal: 12, paddingVertical: 10 },
  providerBubble: {
    backgroundColor: PAGE_BG,
    borderBottomLeftRadius: 4,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: BORDER,
    ...shadowSm,
  },
  userBubble: { backgroundColor: PRIMARY, borderBottomRightRadius: 4 },
  bubbleText: { fontSize: isSmallDevice ? 14 : 15, lineHeight: 20, fontWeight: '500', color: TEXT_BLACK },
  userText: { color: '#FFFFFF' },
  bubbleFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  bubbleFooterUser: { marginLeft: 12 },
  bubbleTime: { fontSize: 10, fontWeight: '500', color: TEXT_MUTED },
  userTime: { color: 'rgba(255,255,255,0.75)' },
  editedLabel: { fontSize: 10, fontWeight: '600', color: TEXT_MUTED, fontStyle: 'italic' },
  deletedBubble: {
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: BORDER,
    borderStyle: 'dashed',
  },
  deletedText: { fontSize: 12, color: TEXT_MUTED, fontStyle: 'italic' },
  reactionsBadge: {
    position: 'absolute',
    bottom: -6,
    backgroundColor: PAGE_BG,
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: BORDER,
    ...shadowSm,
  },
  reactionsBadgeUser: { left: 6 },
  reactionsBadgeProvider: { right: 6 },
  reactionsEmoji: { fontSize: 13, lineHeight: 16 },
  attachCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#F5F7F5',
    borderRadius: 10,
    padding: 8,
    marginTop: 4,
  },
  attachCardUser: { backgroundColor: 'rgba(255,255,255,0.15)' },
  attachThumb: { width: 48, height: 48, borderRadius: 8, backgroundColor: '#E8EDEA' },
  attachIconBox: {
    width: 48,
    height: 48,
    borderRadius: 8,
    backgroundColor: '#E8EDEA',
    alignItems: 'center',
    justifyContent: 'center',
  },
  attachEmoji: { fontSize: 22 },
  attachInfo: { flex: 1, minWidth: 0 },
  attachName: { fontSize: 12, fontWeight: '700', color: TEXT_BLACK },
  attachNameUser: { color: '#FFFFFF' },
  attachMeta: { fontSize: 10, color: TEXT_DESC, marginTop: 2 },
  attachMetaUser: { color: 'rgba(255,255,255,0.8)' },
  playBtn: { fontSize: 16 },
  voiceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#F5F7F5',
    borderRadius: 10,
    padding: 8,
  },
  voiceRowUser: { backgroundColor: 'rgba(255,255,255,0.15)' },
  voicePlay: { fontSize: 14, color: PRIMARY },
  waveform: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 2, height: 20 },
  waveBar: { width: 3, borderRadius: 2, backgroundColor: PRIMARY },
  waveBarUser: { backgroundColor: 'rgba(255,255,255,0.9)' },
  voiceDuration: { fontSize: 11, fontWeight: '600', color: TEXT_DESC },
  voiceDurationUser: { color: 'rgba(255,255,255,0.85)' },
  transcriptBox: {
    marginTop: 6,
    padding: 8,
    backgroundColor: 'rgba(0,0,0,0.04)',
    borderRadius: 8,
  },
  transcriptLabel: { fontSize: 9, fontWeight: '700', color: TEXT_MUTED, marginBottom: 2 },
  transcriptText: { fontSize: 11, color: TEXT_DESC, lineHeight: 16 },
  markdownBlock: { gap: 2 },
  markdownLine: { fontSize: 14, lineHeight: 20, color: TEXT_BLACK },
  markdownBold: { fontWeight: '800' },
  markdownBullet: { paddingLeft: 4 },
  actionsRow: { flexDirection: 'row', gap: 6, marginTop: 6 },
  actionChip: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    backgroundColor: '#F3F4F6',
  },
  actionText: { fontSize: 10, fontWeight: '700', color: TEXT_DESC },
});
