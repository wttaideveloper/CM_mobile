import { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';

import { AI_CONVERSATION_SUMMARY, AI_MEETING_SUMMARY } from '@/constants/chat';
import { isSmallDevice } from '@/utils/responsive';

const PRIMARY = '#1F5D4E';
const MINT = '#EAF4EC';
const PAGE_BG = '#FFFFFF';
const TEXT_MUTED = '#9CA3AF';
const TEXT_DESC = '#6B7280';
const TEXT_BLACK = '#111111';
const BORDER = '#E8EDEA';

export function ChatSearchPanel({ visible }: { visible: boolean; onClose?: () => void }) {
  const [tab, setTab] = useState<'messages' | 'users' | 'businesses' | 'attachments'>('messages');

  if (!visible) return null;

  const tabs = [
    { key: 'messages' as const, label: 'Messages' },
    { key: 'users' as const, label: 'Users' },
    { key: 'businesses' as const, label: 'Businesses' },
    { key: 'attachments' as const, label: 'Files' },
  ];

  const results: Record<string, string[]> = {
    messages: ['"meal plan" in chat · 10:05 AM', '"arrive early" in chat · 10:02 AM'],
    users: ['Alex Martinez · Trainer', 'Dr. Sarah Kim · Nutritionist'],
    businesses: ['Pinnacle Wellness · Studio 3', 'Pinnacle Wellness · Online'],
    attachments: ['Meal-Plan-Week1.pdf', 'warm-up-demo.mp4', 'progress-photo.jpg'],
  };

  return (
    <View style={styles.panel}>
      <View style={styles.searchRow}>
        <Ionicons name="search-outline" size={18} color={TEXT_MUTED} style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search messages, users, files..."
          placeholderTextColor={TEXT_MUTED}
          autoFocus
        />
      </View>

      <View style={styles.tabs}>
        {tabs.map((t) => (
          <Pressable
            key={t.key}
            onPress={() => setTab(t.key)}
            style={[styles.tab, tab === t.key && styles.tabActive]}
          >
            <Text style={[styles.tabText, tab === t.key && styles.tabTextActive]}>{t.label}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={styles.searchHint}>Full-text search · Elasticsearch</Text>

      {results[tab].map((item) => (
        <Pressable key={item} style={styles.resultRow}>
          <Text style={styles.resultText}>{item}</Text>
        </Pressable>
      ))}
    </View>
  );
}

export function ChatAiSummaryCard({ expanded: initial = false }: { expanded?: boolean }) {
  const [expanded, setExpanded] = useState(initial);

  return (
    <Pressable onPress={() => setExpanded(!expanded)} style={styles.aiCard}>
      <View style={styles.aiHeader}>
        <Text style={styles.aiBadge}>✨ AI Summary</Text>
        <Text style={styles.aiToggle}>{expanded ? '▲' : '▼'}</Text>
      </View>
      {expanded ? (
        <View style={styles.aiBody}>
          <Text style={styles.aiSectionLabel}>Conversation</Text>
          <Text style={styles.aiText}>{AI_CONVERSATION_SUMMARY}</Text>
          <Text style={styles.aiSectionLabel}>Meeting</Text>
          <Text style={styles.aiText}>{AI_MEETING_SUMMARY}</Text>
        </View>
      ) : (
        <Text style={styles.aiPreview} numberOfLines={1}>{AI_CONVERSATION_SUMMARY}</Text>
      )}
    </Pressable>
  );
}

export function ChatGroupMembers({ members }: { members: string[] }) {
  return (
    <View style={styles.groupRow}>
      <Text style={styles.groupLabel}>Group · {members.length} members</Text>
      <View style={styles.memberAvatars}>
        {members.slice(0, 4).map((name) => (
          <View key={name} style={styles.memberChip}>
            <Text style={styles.memberInitial}>{name.charAt(0)}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

export function ChatLoadOlder({ cursor, onLoad }: { cursor: string; onLoad?: () => void }) {
  return (
    <Pressable onPress={onLoad} style={styles.loadOlder}>
      <Text style={styles.loadOlderText}>↑ Load older messages</Text>
      <Text style={styles.loadOlderMeta}>Cursor pagination · {cursor}</Text>
    </Pressable>
  );
}

export function ChatLiveBadge() {
  return (
    <View style={styles.liveBadge}>
      <View style={styles.liveDot} />
      <Text style={styles.liveText}>Live</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  panel: {
    backgroundColor: PAGE_BG,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
    paddingHorizontal: isSmallDevice ? 16 : 20,
    paddingBottom: 10,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
    backgroundColor: '#F5F7F5',
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 40,
  },
  searchIcon: { marginTop: 1 },
  searchInput: {
    flex: 1,
    height: 40,
    fontSize: 14,
    color: TEXT_BLACK,
    paddingVertical: 0,
    textAlignVertical: 'center',
  },
  tabs: { flexDirection: 'row', gap: 6, marginBottom: 8 },
  tab: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    backgroundColor: '#F3F4F6',
  },
  tabActive: { backgroundColor: MINT },
  tabText: { fontSize: 11, fontWeight: '600', color: TEXT_MUTED },
  tabTextActive: { color: PRIMARY, fontWeight: '700' },
  searchHint: { fontSize: 10, color: TEXT_MUTED, marginBottom: 6 },
  resultRow: {
    paddingVertical: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
  },
  resultText: { fontSize: 13, color: TEXT_BLACK, fontWeight: '500' },
  aiCard: {
    marginHorizontal: isSmallDevice ? 16 : 20,
    marginTop: 8,
    marginBottom: 4,
    backgroundColor: '#F0F9FF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#BAE6FD',
    padding: 10,
  },
  aiHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  aiBadge: { fontSize: 12, fontWeight: '800', color: '#0369A1' },
  aiToggle: { fontSize: 10, color: '#0369A1' },
  aiBody: { marginTop: 8, gap: 6 },
  aiSectionLabel: { fontSize: 10, fontWeight: '700', color: '#0284C7', marginTop: 4 },
  aiText: { fontSize: 12, lineHeight: 18, color: TEXT_DESC },
  aiPreview: { fontSize: 11, color: TEXT_DESC, marginTop: 4 },
  groupRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: isSmallDevice ? 16 : 20,
    paddingVertical: 6,
    backgroundColor: MINT,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
  },
  groupLabel: { fontSize: 11, fontWeight: '700', color: PRIMARY },
  memberAvatars: { flexDirection: 'row', gap: 4 },
  memberChip: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: PRIMARY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  memberInitial: { fontSize: 10, fontWeight: '800', color: '#FFFFFF' },
  loadOlder: {
    alignItems: 'center',
    paddingVertical: 10,
    marginBottom: 4,
  },
  loadOlderText: { fontSize: 12, fontWeight: '700', color: PRIMARY },
  loadOlderMeta: { fontSize: 10, color: TEXT_MUTED, marginTop: 2 },
  liveBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
    backgroundColor: '#FEF2F2',
  },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#EF4444' },
  liveText: { fontSize: 10, fontWeight: '700', color: '#B91C1C' },
});
