import { Ionicons } from '@expo/vector-icons';
import { useEffect, useRef } from 'react';
import { Pressable, Platform, StyleSheet, Text, TextInput, View } from 'react-native';

import { isSmallDevice } from '@/utils/responsive';

const PRIMARY = '#1F5D4E';
const PAGE_BG = '#FFFFFF';
const TEXT_MUTED = '#9CA3AF';
const TEXT_BLACK = '#111111';
const PILL_BORDER = '#E0E0E0';

export type RecordingState = {
  active: boolean;
  seconds: number;
};

type ChatComposerProps = {
  draft: string;
  onChangeDraft: (text: string) => void;
  onSend: () => void;
  disabled?: boolean;
  recording: RecordingState;
  onStartRecording: () => void;
  onCancelRecording: () => void;
  onSendRecording: () => void;
  onInputFocus?: () => void;
  onAttach?: () => void;
};

const ACTION_SIZE = 48;

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function ActionButton({
  icon,
  onPress,
  filled,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  filled?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.actionBtn,
        filled && styles.actionBtnFilled,
        pressed && styles.pressed,
      ]}
      hitSlop={4}
    >
      <Ionicons name={icon} size={filled ? 20 : 22} color={filled ? PAGE_BG : TEXT_MUTED} />
    </Pressable>
  );
}

export function ChatComposer({
  draft,
  onChangeDraft,
  onSend,
  disabled,
  recording,
  onStartRecording,
  onCancelRecording,
  onSendRecording,
  onInputFocus,
  onAttach,
}: ChatComposerProps) {
  const inputRef = useRef<TextInput>(null);
  const hasText = draft.trim().length > 0;

  useEffect(() => {
    if (recording.active) {
      inputRef.current?.blur();
    }
  }, [recording.active]);

  if (disabled) {
    return (
      <View style={styles.disabledBox}>
        <Text style={styles.disabledText}>Chat input disabled</Text>
      </View>
    );
  }

  if (recording.active) {
    return (
      <View style={styles.row}>
        <View style={styles.inputPill}>
          <Pressable onPress={onCancelRecording} style={styles.pillIconBtn} hitSlop={6}>
            <Ionicons name="trash-outline" size={22} color="#EF4444" />
          </Pressable>
          <View style={styles.recordingCenter}>
            <View style={styles.recordingDot} />
            <View style={styles.waveform}>
              {[4, 7, 5, 9, 6, 8, 4, 10, 5, 7, 6, 9].map((h, i) => (
                <View key={i} style={[styles.waveBar, { height: h * 2 }]} />
              ))}
            </View>
            <Text style={styles.recordingTime}>{formatTime(recording.seconds)}</Text>
          </View>
        </View>
        <ActionButton icon="send" onPress={onSendRecording} filled />
      </View>
    );
  }

  return (
    <View style={styles.row}>
      <View style={styles.inputPill}>
        <Pressable style={styles.pillIconBtn} hitSlop={4}>
          <Ionicons name="happy-outline" size={24} color={TEXT_MUTED} />
        </Pressable>

        <TextInput
          ref={inputRef}
          style={styles.input}
          placeholder="Message"
          placeholderTextColor={TEXT_MUTED}
          value={draft}
          onChangeText={onChangeDraft}
          onFocus={onInputFocus}
          multiline
          maxLength={2000}
        />

        <Pressable onPress={onAttach} style={styles.pillIconBtn} hitSlop={4}>
          <Ionicons name="attach" size={22} color={TEXT_MUTED} />
        </Pressable>
        <Pressable style={styles.pillIconBtn} hitSlop={4}>
          <Ionicons name="camera-outline" size={22} color={TEXT_MUTED} />
        </Pressable>
      </View>

      {hasText ? (
        <ActionButton icon="send" onPress={onSend} filled />
      ) : (
        <ActionButton icon="mic" onPress={onStartRecording} filled />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 8,
    minHeight: ACTION_SIZE,
  },
  inputPill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: ACTION_SIZE,
    maxHeight: 120,
    borderRadius: ACTION_SIZE / 2,
    backgroundColor: PAGE_BG,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: PILL_BORDER,
    paddingLeft: 2,
    paddingRight: 4,
  },
  pillIconBtn: {
    width: 40,
    height: ACTION_SIZE,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    fontSize: isSmallDevice ? 15 : 16,
    lineHeight: 20,
    color: TEXT_BLACK,
    maxHeight: 100,
    paddingTop: Platform.OS === 'ios' ? 14 : 12,
    paddingBottom: Platform.OS === 'ios' ? 14 : 12,
    paddingHorizontal: 2,
    textAlignVertical: 'center',
  },
  actionBtn: {
    width: ACTION_SIZE,
    height: ACTION_SIZE,
    borderRadius: ACTION_SIZE / 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionBtnFilled: {
    backgroundColor: PRIMARY,
  },
  recordingCenter: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingRight: 8,
  },
  recordingDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#EF4444',
  },
  waveform: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    height: 24,
  },
  waveBar: {
    width: 3,
    borderRadius: 2,
    backgroundColor: PRIMARY,
    opacity: 0.7,
  },
  recordingTime: {
    fontSize: 13,
    fontWeight: '700',
    color: TEXT_BLACK,
    minWidth: 36,
    textAlign: 'right',
  },
  disabledBox: {
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
    padding: 12,
    alignItems: 'center',
  },
  disabledText: { fontSize: 12, fontWeight: '600', color: TEXT_MUTED },
  pressed: { opacity: 0.85 },
});
