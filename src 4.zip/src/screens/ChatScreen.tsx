import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AppStatusBar, StatusBarFill } from '@/components/AppStatusBar';
import { ChatComposer, type RecordingState } from '@/components/chat/ChatComposer';
import {
  ChatAiSummaryCard,
  ChatGroupMembers,
  ChatLiveBadge,
  ChatLoadOlder,
  ChatSearchPanel,
} from '@/components/chat/ChatExtras';
import { ChatMessageItem } from '@/components/chat/ChatMessageItem';
import { ChevronLeftIcon } from '@/components/dashboard/DashboardIcons';
import {
  getMockConversation,
  type ChatMessage,
  type ChatMode,
} from '@/constants/chat';
import { shadowSm } from '@/utils/shadows';
import { isSmallDevice } from '@/utils/responsive';

const PRIMARY = '#1F5D4E';
const PAGE_BG = '#FFFFFF';
const BODY_BG = '#F5F7F5';
const TEXT_MUTED = '#9CA3AF';
const TEXT_DESC = '#6B7280';
const TEXT_BLACK = '#111111';
const BORDER = '#E8EDEA';
const H_PAD = isSmallDevice ? 16 : 20;
/** Small breathing room between keyboard top and message composer (WhatsApp-like). */
const KEYBOARD_COMPOSER_GAP = 6;

function paramValue(value?: string | string[]): string {
  return Array.isArray(value) ? (value[0] ?? '') : (value ?? '');
}

function parseMode(value: string): ChatMode {
  if (value === 'full' || value === 'readonly') return value;
  return 'preview';
}

function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function TypingIndicator({ name }: { name: string }) {
  return (
    <View style={styles.typingRow}>
      <View style={styles.typingBubble}>
        <View style={styles.typingDots}>
          <View style={styles.typingDot} />
          <View style={[styles.typingDot, styles.typingDotMid]} />
          <View style={styles.typingDot} />
        </View>
        <Text style={styles.typingText}>{name} is typing...</Text>
      </View>
    </View>
  );
}

function ProviderAvatar({ initial, isGroup }: { initial: string; isGroup?: boolean }) {
  const size = isSmallDevice ? 36 : 40;

  if (isGroup) {
    return (
      <View
        style={{
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: '#EAF4EC',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name="people" size={isSmallDevice ? 18 : 20} color={PRIMARY} />
      </View>
    );
  }

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        <Defs>
          <LinearGradient id="chatAvatarGrad" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#1F5D4E" />
            <Stop offset="1" stopColor="#3E7041" />
          </LinearGradient>
        </Defs>
        <Rect x={0} y={0} width={size} height={size} rx={12} fill="url(#chatAvatarGrad)" />
      </Svg>
      <Text style={styles.avatarText}>{initial}</Text>
    </View>
  );
}

function ChatBanner({
  mode,
  previewUsed,
  previewLimit,
  planUsed,
  planLimit,
  planName,
  loadedCount,
}: {
  mode: ChatMode;
  previewUsed: number;
  previewLimit: number;
  planUsed: number;
  planLimit: number | null;
  planName: string;
  loadedCount: number;
}) {
  if (mode === 'preview') {
    const remaining = previewLimit - previewUsed;
    const isLimitReached = remaining <= 0;

    return (
      <View style={[styles.banner, isLimitReached ? styles.bannerWarning : styles.bannerInfo]}>
        <Text style={[styles.bannerTitle, isLimitReached && styles.bannerTitleWarning]}>
          {isLimitReached ? 'Preview limit reached' : `Preview · ${previewUsed}/${previewLimit} messages`}
        </Text>
        <Text style={[styles.bannerDesc, isLimitReached && styles.bannerDescWarning]}>
          {isLimitReached ? 'Book this service to continue' : `${remaining} left · ${loadedCount} messages loaded`}
        </Text>
      </View>
    );
  }

  if (mode === 'readonly') {
    return (
      <View style={[styles.banner, styles.bannerMuted]}>
        <Text style={styles.bannerTitle}>Read-only · Message history preserved</Text>
        <Text style={styles.bannerDesc}>Archived after 48 hours</Text>
      </View>
    );
  }

  if (planLimit !== null) {
    const pct = Math.min(100, Math.round((planUsed / planLimit) * 100));
    return (
      <View style={[styles.banner, styles.bannerInfo]}>
        <View style={styles.usageRow}>
          <Text style={styles.bannerTitle}>{planName} · {planUsed}/{planLimit}</Text>
          <Text style={styles.usagePct}>{pct}%</Text>
        </View>
        <View style={styles.usageTrack}>
          <View style={[styles.usageFill, { width: `${pct}%` }]} />
        </View>
      </View>
    );
  }

  return null;
}

export function ChatScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{
    id: string;
    mode?: string;
    title?: string;
    provider?: string;
    enterprise?: string;
    members?: string;
  }>();

  const conversationId = paramValue(params.id);
  const mode = parseMode(paramValue(params.mode));
  const title = paramValue(params.title) || undefined;
  const provider = paramValue(params.provider) || undefined;
  const enterprise = paramValue(params.enterprise) || undefined;
  const membersParam = paramValue(params.members);
  const membersOverride = useMemo(
    () =>
      membersParam
        ? membersParam.split(',').map((name) => name.trim()).filter(Boolean)
        : undefined,
    [membersParam],
  );
  const isNewGroup = conversationId.startsWith('group-');

  const { meta, messages: initialMessages } = useMemo(
    () =>
      getMockConversation(conversationId, mode, {
        title,
        provider,
        enterprise,
        members: membersOverride,
      }),
    [conversationId, mode, title, provider, enterprise, membersOverride],
  );

  const groupSubtitle = useMemo(() => {
    if (!meta.isGroup) {
      return `${meta.enterprise} · ${meta.isOnline ? 'Online' : 'Offline'}`;
    }

    const others = meta.members.filter((name) => name !== 'You');
    if (others.length === 0) return 'Group · tap for info';
    if (others.length <= 2) return others.join(', ');
    return `${others.slice(0, 2).join(', ')} and ${others.length - 2} more`;
  }, [meta.enterprise, meta.isGroup, meta.isOnline, meta.members]);

  const [draft, setDraft] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [showTyping, setShowTyping] = useState(mode === 'full' && !isNewGroup);
  const [showSearch, setShowSearch] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [hasOlder, setHasOlder] = useState(meta.hasOlderMessages);
  const [recording, setRecording] = useState<RecordingState>({ active: false, seconds: 0 });
  const recordingTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const listRef = useRef<FlatList>(null);
  const [androidKeyboardPad, setAndroidKeyboardPad] = useState(0);

  const previewLimitReached = meta.mode === 'preview' && meta.previewUsed >= meta.previewLimit;
  const canSend = meta.mode === 'full' || (meta.mode === 'preview' && !previewLimitReached);
  const inputDisabled = !canSend;
  const showFullFeatures = meta.mode === 'full';

  const scrollToEnd = (animated = true) => {
    if (messages.length === 0) return;

    const scroll = () => {
      listRef.current?.scrollToEnd({ animated });
      if (messages.length > 1) {
        listRef.current?.scrollToIndex({
          index: messages.length - 1,
          animated,
          viewPosition: 1,
        });
      }
    };

    requestAnimationFrame(scroll);
    setTimeout(scroll, 100);
    setTimeout(scroll, 260);
  };

  useEffect(() => {
    return () => {
      if (recordingTimer.current) clearInterval(recordingTimer.current);
    };
  }, []);

  useEffect(() => {
    if (Platform.OS !== 'android') return undefined;

    const showSub = Keyboard.addListener('keyboardDidShow', (event) => {
      setAndroidKeyboardPad(event.endCoordinates.height);
      scrollToEnd(true);
    });
    const hideSub = Keyboard.addListener('keyboardDidHide', () => {
      setAndroidKeyboardPad(0);
    });

    return () => {
      showSub.remove();
      hideSub.remove();
    };
  }, []);

  useEffect(() => {
    if (Platform.OS !== 'ios') return undefined;

    const showSub = Keyboard.addListener('keyboardWillShow', () => {
      scrollToEnd(true);
    });

    return () => {
      showSub.remove();
    };
  }, []);

  useEffect(() => {
    if (androidKeyboardPad > 0) {
      scrollToEnd(true);
    }
  }, [androidKeyboardPad, messages.length]);

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [messages.length, showTyping]);

  const startRecording = () => {
    setRecording({ active: true, seconds: 0 });
    recordingTimer.current = setInterval(() => {
      setRecording((prev) => ({ ...prev, seconds: prev.seconds + 1 }));
    }, 1000);
  };

  const stopRecordingTimer = () => {
    if (recordingTimer.current) {
      clearInterval(recordingTimer.current);
      recordingTimer.current = null;
    }
  };

  const cancelRecording = () => {
    stopRecordingTimer();
    setRecording({ active: false, seconds: 0 });
  };

  const sendRecording = () => {
    const durationSeconds = recording.seconds || 1;
    stopRecordingTimer();
    setRecording({ active: false, seconds: 0 });

    setMessages((prev) => [
      ...prev,
      {
        id: `voice-${Date.now()}`,
        sender: 'user',
        timestamp: 'Just now',
        status: 'sent',
        messageType: 'voice',
        voice: {
          duration: formatDuration(durationSeconds),
          transcript: 'Voice message',
        },
      },
    ]);
    setShowTyping(true);
  };

  const handleSend = () => {
    const text = draft.trim();
    if (!text || inputDisabled) return;

    setMessages((prev) => [
      ...prev,
      {
        id: `user-${Date.now()}`,
        text,
        sender: 'user',
        timestamp: 'Just now',
        status: 'sent',
        messageType: 'text',
      },
    ]);
    setDraft('');
    setShowTyping(true);
  };

  const handleLoadOlder = () => {
    setLoadingOlder(true);
    setTimeout(() => {
      setMessages((prev) => [
        {
          id: `older-${Date.now()}`,
          text: 'Older message loaded from history',
          sender: 'provider',
          timestamp: 'Last week',
          messageType: 'text',
        },
        ...prev,
      ]);
      setHasOlder(false);
      setLoadingOlder(false);
    }, 600);
  };

  const chatBody = (
    <View style={styles.chatArea}>
      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <ChatMessageItem message={item} isGroup={meta.isGroup} />}
        style={styles.messageList}
        contentContainerStyle={styles.messageListContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="always"
        keyboardDismissMode="none"
        onScrollToIndexFailed={(info) => {
          setTimeout(() => {
            listRef.current?.scrollToIndex({
              index: info.index,
              animated: true,
              viewPosition: 1,
            });
          }, 100);
        }}
        ListHeaderComponent={
          hasOlder ? (
            loadingOlder ? (
              <ActivityIndicator color={PRIMARY} style={styles.loader} />
            ) : (
              <ChatLoadOlder cursor={meta.olderCursor} onLoad={handleLoadOlder} />
            )
          ) : null
        }
        ListFooterComponent={
          showTyping && meta.isOnline ? <TypingIndicator name={meta.provider} /> : null
        }
      />

      <View style={[styles.composer, { paddingBottom: Math.max(insets.bottom, 6) }]}>
        {inputDisabled ? (
          <View style={styles.composerDisabled}>
            <Text style={styles.composerDisabledText}>
              {meta.mode === 'readonly'
                ? 'Chat closed · Book again to start a new conversation'
                : 'Message limit reached · Book this service to continue'}
            </Text>
          </View>
        ) : (
          <ChatComposer
            draft={draft}
            onChangeDraft={setDraft}
            onSend={handleSend}
            recording={recording}
            onStartRecording={startRecording}
            onCancelRecording={cancelRecording}
            onSendRecording={sendRecording}
            onInputFocus={() => scrollToEnd(true)}
          />
        )}
      </View>
    </View>
  );

  return (
    <View style={styles.screen}>
      <AppStatusBar backgroundColor={PAGE_BG} />
      <StatusBarFill lightColor={PAGE_BG} darkColor={PAGE_BG} />

      <View style={[styles.header, { paddingTop: 12 }]}>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [styles.backBtn, pressed && styles.pressed]}
          hitSlop={8}
        >
          <ChevronLeftIcon size={22} color={TEXT_BLACK} />
        </Pressable>

        <ProviderAvatar initial={meta.avatarInitial} isGroup={meta.isGroup} />

        <View style={styles.headerInfo}>
          <View style={styles.headerTitleRow}>
            <Text style={styles.headerTitle} numberOfLines={1}>
              {meta.isGroup ? meta.title : meta.provider}
            </Text>
            {meta.isOnline && !meta.isGroup ? <ChatLiveBadge /> : null}
          </View>
          <Text style={styles.headerSubtitle} numberOfLines={1}>
            {groupSubtitle}
          </Text>
        </View>

        <Pressable
          onPress={() => setShowSearch(!showSearch)}
          style={({ pressed }) => [styles.headerActionBtn, pressed && styles.pressed]}
          hitSlop={8}
        >
          <Ionicons name="search-outline" size={22} color={TEXT_BLACK} />
        </Pressable>

        {meta.isGroup ? (
          <Pressable
            style={({ pressed }) => [styles.headerActionBtn, pressed && styles.pressed]}
            hitSlop={8}
          >
            <Ionicons name="ellipsis-vertical" size={22} color={TEXT_BLACK} />
          </Pressable>
        ) : null}
      </View>

      <ChatSearchPanel visible={showSearch} onClose={() => setShowSearch(false)} />
      {!isNewGroup && meta.isGroup ? <ChatGroupMembers members={meta.members} /> : null}

      {!isNewGroup ? (
        <ChatBanner
          mode={meta.mode}
          previewUsed={meta.previewUsed}
          previewLimit={meta.previewLimit}
          planUsed={meta.planUsed}
          planLimit={meta.planLimit}
          planName={meta.planName}
          loadedCount={messages.length}
        />
      ) : null}

      {showFullFeatures && !isNewGroup ? <ChatAiSummaryCard /> : null}

      <KeyboardAvoidingView
        style={[
          styles.flex,
          androidKeyboardPad > 0 && { paddingBottom: androidKeyboardPad + KEYBOARD_COMPOSER_GAP },
        ]}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? insets.top : 0}
      >
        {chatBody}
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BODY_BG },
  flex: { flex: 1 },
  chatArea: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: isSmallDevice ? 10 : 12,
    paddingHorizontal: H_PAD,
    paddingBottom: isSmallDevice ? 10 : 12,
    backgroundColor: PAGE_BG,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
    ...shadowSm,
  },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: BODY_BG,
  },
  headerInfo: { flex: 1, minWidth: 0 },
  headerTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  headerTitle: {
    fontSize: isSmallDevice ? 15 : 16,
    fontWeight: '800',
    color: TEXT_BLACK,
    flexShrink: 1,
  },
  headerSubtitle: {
    fontSize: isSmallDevice ? 11 : 12,
    fontWeight: '500',
    color: TEXT_DESC,
    marginTop: 1,
  },
  headerActionBtn: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { fontWeight: '800', color: '#FFFFFF', fontSize: isSmallDevice ? 15 : 16, zIndex: 1 },
  banner: {
    paddingHorizontal: H_PAD,
    paddingVertical: isSmallDevice ? 8 : 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
  },
  bannerInfo: { backgroundColor: '#F0FDF4' },
  bannerWarning: { backgroundColor: '#FFF7ED' },
  bannerMuted: { backgroundColor: '#F3F4F6' },
  bannerTitle: { fontSize: isSmallDevice ? 12 : 13, fontWeight: '800', color: PRIMARY },
  bannerTitleWarning: { color: '#C2410C' },
  bannerDesc: { fontSize: isSmallDevice ? 11 : 12, fontWeight: '500', color: TEXT_DESC, marginTop: 2 },
  bannerDescWarning: { color: '#9A3412' },
  usageRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  usagePct: { fontSize: 11, fontWeight: '700', color: PRIMARY },
  usageTrack: { height: 4, borderRadius: 2, backgroundColor: '#D1FAE5', overflow: 'hidden' },
  usageFill: { height: '100%', borderRadius: 2, backgroundColor: PRIMARY },
  messageList: { flex: 1 },
  messageListContent: {
    paddingHorizontal: H_PAD,
    paddingTop: isSmallDevice ? 8 : 12,
    paddingBottom: isSmallDevice ? 12 : 16,
    gap: isSmallDevice ? 8 : 10,
    flexGrow: 1,
  },
  loader: { marginVertical: 10 },
  typingRow: { alignItems: 'flex-start', marginTop: 4 },
  typingBubble: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: PAGE_BG,
    borderRadius: 16,
    borderBottomLeftRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: BORDER,
  },
  typingDots: { flexDirection: 'row', gap: 3 },
  typingDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: TEXT_MUTED, opacity: 0.5 },
  typingDotMid: { opacity: 0.85 },
  typingText: { fontSize: 11, fontWeight: '600', color: TEXT_DESC },
  composer: {
    paddingHorizontal: 6,
    paddingTop: 6,
    paddingBottom: 6,
    backgroundColor: PAGE_BG,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: BORDER,
  },
  composerDisabled: {
    marginHorizontal: H_PAD - 6,
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
    padding: 12,
    alignItems: 'center',
  },
  composerDisabledText: { fontSize: 12, fontWeight: '600', color: TEXT_DESC, textAlign: 'center' },
  pressed: { opacity: 0.9 },
});
