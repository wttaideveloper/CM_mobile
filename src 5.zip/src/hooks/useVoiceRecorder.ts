import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, Platform } from 'react-native';
import {
  AudioModule,
  RecordingPresets,
  setAudioModeAsync,
  useAudioPlayer,
  useAudioPlayerStatus,
  useAudioRecorder,
  useAudioRecorderState,
} from 'expo-audio';

import {
  getTotalSegmentSeconds,
  mergeVoiceSegments,
  type VoiceSegment,
} from '@/utils/voiceSegments';

export type VoicePhase = 'idle' | 'recording';

export type VoiceRecordingState = {
  phase: VoicePhase;
  isPaused: boolean;
  seconds: number;
  waveformLevels: number[];
  isPlayingPreview: boolean;
  playbackProgress: number;
  canPreview: boolean;
};

export type VoiceRecordingResult = {
  uri: string;
  durationSeconds: number;
  durationLabel: string;
};

const BAR_COUNT = 28;
const DEFAULT_LEVELS = Array.from({ length: BAR_COUNT }, () => 4);

// AMR/3gp on Android finalizes cleanly on stop() and can be merged after pause/resume.
const VOICE_RECORDING_OPTIONS =
  Platform.OS === 'android' ? RecordingPresets.LOW_QUALITY : RecordingPresets.HIGH_QUALITY;

function formatTime(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function normalizeMetering(metering?: number): number {
  if (metering == null || Number.isNaN(metering)) {
    return 4;
  }

  const clamped = Math.min(0, Math.max(-60, metering));
  return Math.round(((clamped + 60) / 60) * 18) + 4;
}

function showRecordingError(message: string) {
  Alert.alert('Voice recording', message);
}

function safePause(player: { pause: () => void }) {
  try {
    player.pause();
  } catch {
    // player may already be released
  }
}

export function useVoiceRecorder() {
  const [phase, setPhase] = useState<VoicePhase>('idle');
  const [isPaused, setIsPaused] = useState(false);
  const [pausedSeconds, setPausedSeconds] = useState(0);
  const [canPreview, setCanPreview] = useState(false);
  const [waveformLevels, setWaveformLevels] = useState<number[]>(DEFAULT_LEVELS);
  const levelsRef = useRef<number[]>(DEFAULT_LEVELS);
  const phaseRef = useRef<VoicePhase>('idle');
  const isPausedRef = useRef(false);
  const previewUriRef = useRef<string | null>(null);
  const loadedPreviewUriRef = useRef<string | null>(null);
  const segmentsRef = useRef<VoiceSegment[]>([]);
  const stoppedForPreviewRef = useRef(false);

  const recorder = useAudioRecorder({
    ...VOICE_RECORDING_OPTIONS,
    isMeteringEnabled: true,
  });
  const recorderState = useAudioRecorderState(recorder, 120);
  const player = useAudioPlayer(null);
  const playerStatus = useAudioPlayerStatus(player);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  useEffect(() => {
    isPausedRef.current = isPaused;
  }, [isPaused]);

  const recordingSeconds = Math.max(0, Math.floor((recorderState.durationMillis ?? 0) / 1000));
  const totalRecordedSeconds =
    getTotalSegmentSeconds(segmentsRef.current) + (isPaused ? 0 : recordingSeconds);
  const seconds = phase === 'recording' ? (isPaused ? pausedSeconds : totalRecordedSeconds) : 0;

  const playbackProgress =
    isPaused && playerStatus.duration > 0
      ? Math.min(1, playerStatus.currentTime / playerStatus.duration)
      : 0;

  useEffect(() => {
    if (phase !== 'recording' || isPaused) {
      return;
    }

    const nextLevel = normalizeMetering(recorderState.metering);
    levelsRef.current = [...levelsRef.current.slice(1), nextLevel];
    setWaveformLevels(levelsRef.current);
  }, [isPaused, phase, recorderState.metering, recorderState.durationMillis]);

  useEffect(() => {
    if (!isPaused || !playerStatus.playing) {
      return;
    }

    const reachedEnd =
      playerStatus.duration > 0 && playerStatus.currentTime >= playerStatus.duration - 0.05;
    if (reachedEnd) {
      player.seekTo(0);
      safePause(player);
    }
  }, [isPaused, player, playerStatus.currentTime, playerStatus.duration, playerStatus.playing]);

  const resetWaveform = useCallback(() => {
    levelsRef.current = DEFAULT_LEVELS;
    setWaveformLevels(DEFAULT_LEVELS);
  }, []);

  const resetSession = useCallback(() => {
    safePause(player);
    previewUriRef.current = null;
    loadedPreviewUriRef.current = null;
    segmentsRef.current = [];
    stoppedForPreviewRef.current = false;
    setCanPreview(false);
    setIsPaused(false);
    setPausedSeconds(0);
    resetWaveform();
    setPhase('idle');
  }, [player, resetWaveform]);

  const configureRecordingMode = useCallback(async () => {
    await setAudioModeAsync({
      playsInSilentMode: true,
      allowsRecording: true,
      interruptionMode: 'doNotMix',
    });
  }, []);

  const configurePlaybackMode = useCallback(async () => {
    await setAudioModeAsync({
      playsInSilentMode: true,
      allowsRecording: false,
      interruptionMode: 'doNotMix',
    });
  }, []);

  const buildPreviewUri = useCallback(async () => {
    const uris = segmentsRef.current.map((segment) => segment.uri);
    if (uris.length === 0) {
      return null;
    }

    if (uris.length === 1) {
      return uris[0];
    }

    return mergeVoiceSegments(uris);
  }, []);

  const ensurePreviewLoaded = useCallback(
    async (uri: string) => {
      if (loadedPreviewUriRef.current === uri) {
        return;
      }

      player.replace(uri);
      loadedPreviewUriRef.current = uri;
      await new Promise((resolve) => setTimeout(resolve, 120));
    },
    [player],
  );

  const finalizePauseForPreview = useCallback(async () => {
    safePause(player);
    loadedPreviewUriRef.current = null;

    const segmentSeconds = Math.max(1, recordingSeconds);

    // Finalize the file so the native player can read it while paused.
    await recorder.stop();
    stoppedForPreviewRef.current = true;

    const uri = recorder.uri;
    if (!uri) {
      setCanPreview(false);
      setIsPaused(true);
      setPausedSeconds(getTotalSegmentSeconds(segmentsRef.current));
      return;
    }

    segmentsRef.current.push({ uri, durationSeconds: segmentSeconds });

    const previewUri = await buildPreviewUri();
    previewUriRef.current = previewUri;
    setPausedSeconds(getTotalSegmentSeconds(segmentsRef.current));
    setCanPreview(Boolean(previewUri));
    setIsPaused(true);
  }, [buildPreviewUri, player, recorder, recordingSeconds]);

  const startRecording = useCallback(async () => {
    if (phaseRef.current !== 'idle') {
      return;
    }

    try {
      const permission = await AudioModule.requestRecordingPermissionsAsync();
      if (!permission.granted) {
        showRecordingError(
          'Microphone permission is required to record voice messages. Enable it in your device settings.',
        );
        return;
      }

      previewUriRef.current = null;
      loadedPreviewUriRef.current = null;
      segmentsRef.current = [];
      stoppedForPreviewRef.current = false;
      setCanPreview(false);
      resetWaveform();
      setIsPaused(false);
      setPausedSeconds(0);
      setPhase('recording');

      await configureRecordingMode();
      await recorder.prepareToRecordAsync();
      recorder.record();
    } catch (error) {
      console.warn('[useVoiceRecorder] startRecording failed:', error);
      resetSession();
      showRecordingError('Could not start recording. Please try again.');
    }
  }, [configureRecordingMode, recorder, resetSession, resetWaveform]);

  const togglePauseResume = useCallback(async () => {
    if (phaseRef.current !== 'recording') {
      return;
    }

    try {
      if (isPausedRef.current) {
        safePause(player);
        loadedPreviewUriRef.current = null;
        await configureRecordingMode();

        if (stoppedForPreviewRef.current) {
          await recorder.prepareToRecordAsync();
          stoppedForPreviewRef.current = false;
        }

        recorder.record();
        setIsPaused(false);
        return;
      }

      await finalizePauseForPreview();
    } catch (error) {
      console.warn('[useVoiceRecorder] togglePauseResume failed:', error);
      showRecordingError('Could not pause or resume recording. Please try again.');
    }
  }, [configureRecordingMode, finalizePauseForPreview, player, recorder]);

  const togglePreviewPlayback = useCallback(async () => {
    if (!isPausedRef.current) {
      return;
    }

    if (playerStatus.playing) {
      safePause(player);
      return;
    }

    const uri = previewUriRef.current ?? (await buildPreviewUri());
    if (!uri) {
      showRecordingError('Preview is not ready yet. Record for a moment, pause, then try again.');
      return;
    }

    try {
      await configurePlaybackMode();
      previewUriRef.current = uri;
      await ensurePreviewLoaded(uri);

      if (playerStatus.duration > 0 && playerStatus.currentTime >= playerStatus.duration - 0.05) {
        player.seekTo(0);
      }

      player.play();
    } catch (error) {
      console.warn('[useVoiceRecorder] togglePreviewPlayback failed:', error);
      loadedPreviewUriRef.current = null;
      showRecordingError('Could not play the recording preview.');
    }
  }, [
    buildPreviewUri,
    configurePlaybackMode,
    ensurePreviewLoaded,
    player,
    playerStatus.currentTime,
    playerStatus.duration,
    playerStatus.playing,
  ]);

  const cancelRecording = useCallback(async () => {
    try {
      if (phaseRef.current === 'recording' && !isPausedRef.current) {
        await recorder.stop();
      }
    } catch {
      // ignore cleanup errors
    }

    resetSession();
  }, [recorder, resetSession]);

  const finishRecording = useCallback(async (): Promise<VoiceRecordingResult | null> => {
    if (phaseRef.current !== 'recording') {
      return null;
    }

    try {
      safePause(player);

      if (!isPausedRef.current) {
        const segmentSeconds = Math.max(1, recordingSeconds);
        await recorder.stop();
        const uri = recorder.uri;
        if (uri) {
          segmentsRef.current.push({ uri, durationSeconds: segmentSeconds });
        }
      }

      const segments = segmentsRef.current;
      if (segments.length === 0) {
        resetSession();
        showRecordingError('Recording was empty. Please try again.');
        return null;
      }

      const mergedUri = await mergeVoiceSegments(segments.map((segment) => segment.uri));
      if (!mergedUri) {
        resetSession();
        showRecordingError('Could not prepare the voice message. Please try again.');
        return null;
      }

      const durationSeconds = Math.max(1, getTotalSegmentSeconds(segments));
      const result: VoiceRecordingResult = {
        uri: mergedUri,
        durationSeconds,
        durationLabel: formatTime(durationSeconds),
      };

      resetSession();
      return result;
    } catch (error) {
      console.warn('[useVoiceRecorder] finishRecording failed:', error);
      resetSession();
      showRecordingError('Could not send the recording. Please try again.');
      return null;
    }
  }, [player, recorder, recordingSeconds, resetSession]);

  const state: VoiceRecordingState = {
    phase,
    isPaused,
    seconds,
    waveformLevels,
    isPlayingPreview: playerStatus.playing,
    playbackProgress,
    canPreview,
  };

  return {
    state,
    isActive: phase !== 'idle',
    startRecording,
    togglePauseResume,
    togglePreviewPlayback,
    cancelRecording,
    finishRecording,
    formatTime,
  };
}
