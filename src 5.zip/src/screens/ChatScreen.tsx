import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter, useFocusEffect } from 'expo-router';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as DocumentPicker from 'expo-document-picker';
import {
  ActivityIndicator,
  Alert,
  BackHandler,
  FlatList,
  Keyboard,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  type LayoutChangeEvent,
  type ScrollViewProps,
} from 'react-native';
import { KeyboardStickyView, useKeyboardHandler } from 'react-native-keyboard-controller';
import { runOnJS, useSharedValue, withTiming } from 'react-native-reanimated';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';

import { AppStatusBar, StatusBarFill } from '@/components/AppStatusBar';
import { ChatComposer } from '@/components/chat/ChatComposer';
import {
  CHAT_COMPOSER_BASE_HEIGHT,
  CHAT_COMPOSER_GAP,
  CHAT_MESSAGE_COMPOSER_GAP,
  ChatKeyboardScrollView,
} from '@/components/chat/ChatKeyboardScrollView';
import { ChatImageViewer } from '@/components/chat/ChatImageViewer';
import {
  ChatAiSummaryCard,
  ChatGroupMembers,
  ChatLiveBadge,
  ChatLoadOlder,
  ChatSearchPanel,
} from '@/components/chat/ChatExtras';
import { ChatMessageItem } from '@/components/chat/ChatMessageItem';
import { ChevronLeftIcon } from '@/components/dashboard/DashboardIcons';
import {
  getMockConversation,
  type ChatMessage,
  type ChatMode,
} from '@/constants/chat';
import { API_CONFIG } from '@/config';
import { DEV_USER } from '@/constants/devUser';
import { useChatCamera } from '@/hooks/useChatCamera';
import { useConversationRoom } from '@/hooks/useConversationRoom';
import { useConversationTyping } from '@/hooks/useConversationTyping';
import { useRemoteTypingUsers } from '@/hooks/useRemoteTypingUsers';
import { useSocketTyping } from '@/hooks/useSocketTyping';
import { useVoiceRecorder } from '@/hooks/useVoiceRecorder';
import { SOCKET_SERVER_EVENTS } from '@/constants/socket.events';
import { fetchConversationById, markConversationAsRead } from '@/services/conversation.service';
import { editMessage, fetchConversationMessages, deleteMessage } from '@/services/message.service';
import { getSocket, isSocketConnected } from '@/services/socket/socket.client';
import { markMessageReadViaSocket } from '@/services/socket/socket.typing.service';
import {
  sendMessageViaSocket,
  subscribeToNewMessageEvents,
} from '@/services/socket/socket.message.service';
import { useAuthStore } from '@/stores/auth.store';
import { uploadAndSendAttachmentMessage } from '@/services/attachments.service';
import type { Conversation } from '@/types/conversation.types';
import { isApiConversationId } from '@/utils/conversation';
import { mapApiMessageToChatMessage } from '@/utils/message.mapper';
import {
  hydrateChatMessagesFromApi,
  hydrateSingleChatMessageFromApi,
} from '@/utils/attachment.hydration';
import { shadowSm } from '@/utils/shadows';
import { isSmallDevice } from '@/utils/responsive';

const PRIMARY = '#1F5D4E';
const PAGE_BG = '#FFFFFF';
const BODY_BG = '#F5F7F5';
const TEXT_MUTED = '#9CA3AF';
const TEXT_DESC = '#6B7280';
const TEXT_BLACK = '#111111';
const BORDER = '#E8EDEA';
const H_PAD = isSmallDevice ? 16 : 20;

function paramValue(value?: string | string[]): string {
  return Array.isArray(value) ? (value[0] ?? '') : (value ?? '');
}

function parseMode(value: string): ChatMode {
  if (value === 'full' || value === 'readonly') return value;
  return 'preview';
}

function TypingIndicator({ name }: { name: string }) {
  return (
    <View style={styles.typingRow}>
      <View style={styles.typingBubble}>
        <View style={styles.typingDots}>
          <View style={styles.typingDot} />
          <View style={[styles.typingDot, styles.typingDotMid]} />
          <View style={styles.typingDot} />
        </View>
        <Text style={styles.typingText}>{name} is typing...</Text>
      </View>
    </View>
  );
}

function ProviderAvatar({ initial, isGroup }: { initial: string; isGroup?: boolean }) {
  const size = isSmallDevice ? 36 : 40;

  if (isGroup) {
    return (
      <View
        style={{
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: '#EAF4EC',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name="people" size={isSmallDevice ? 18 : 20} color={PRIMARY} />
      </View>
    );
  }

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        <Defs>
          <LinearGradient id="chatAvatarGrad" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#1F5D4E" />
            <Stop offset="1" stopColor="#3E7041" />
          </LinearGradient>
        </Defs>
        <Rect x={0} y={0} width={size} height={size} rx={12} fill="url(#chatAvatarGrad)" />
      </Svg>
      <Text style={styles.avatarText}>{initial}</Text>
    </View>
  );
}

function ChatBanner({
  mode,
  previewUsed,
  previewLimit,
  planUsed,
  planLimit,
  planName,
  loadedCount,
}: {
  mode: ChatMode;
  previewUsed: number;
  previewLimit: number;
  planUsed: number;
  planLimit: number | null;
  planName: string;
  loadedCount: number;
}) {
  if (mode === 'preview') {
    const remaining = previewLimit - previewUsed;
    const isLimitReached = remaining <= 0;

    return (
      <View style={[styles.banner, isLimitReached ? styles.bannerWarning : styles.bannerInfo]}>
        <Text style={[styles.bannerTitle, isLimitReached && styles.bannerTitleWarning]}>
          {isLimitReached ? 'Preview limit reached' : `Preview · ${previewUsed}/${previewLimit} messages`}
        </Text>
        <Text style={[styles.bannerDesc, isLimitReached && styles.bannerDescWarning]}>
          {isLimitReached ? 'Book this service to continue' : `${remaining} left · ${loadedCount} messages loaded`}
        </Text>
      </View>
    );
  }

  if (mode === 'readonly') {
    return (
      <View style={[styles.banner, styles.bannerMuted]}>
        <Text style={styles.bannerTitle}>Read-only · Message history preserved</Text>
        <Text style={styles.bannerDesc}>Archived after 48 hours</Text>
      </View>
    );
  }

  if (planLimit !== null) {
    const pct = Math.min(100, Math.round((planUsed / planLimit) * 100));
    return (
      <View style={[styles.banner, styles.bannerInfo]}>
        <View style={styles.usageRow}>
          <Text style={styles.bannerTitle}>{planName} · {planUsed}/{planLimit}</Text>
          <Text style={styles.usagePct}>{pct}%</Text>
        </View>
        <View style={styles.usageTrack}>
          <View style={[styles.usageFill, { width: `${pct}%` }]} />
        </View>
      </View>
    );
  }

  return null;
}

export function ChatScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{
    id: string;
    mode?: string;
    title?: string;
    provider?: string;
    enterprise?: string;
    members?: string;
  }>();

  const conversationId = paramValue(params.id);
  const mode = parseMode(paramValue(params.mode));
  const title = paramValue(params.title) || undefined;
  const provider = paramValue(params.provider) || undefined;
  const enterprise = paramValue(params.enterprise) || undefined;
  const membersParam = paramValue(params.members);
  const membersOverride = useMemo(
    () =>
      membersParam
        ? membersParam.split(',').map((name) => name.trim()).filter(Boolean)
        : undefined,
    [membersParam],
  );
  const isNewGroup = conversationId.startsWith('group-');
  const isLiveConversation = isApiConversationId(conversationId);

  const { meta, messages: initialMessages } = useMemo(
    () =>
      getMockConversation(conversationId, mode, {
        title,
        provider,
        enterprise,
        members: membersOverride,
      }),
    [conversationId, mode, title, provider, enterprise, membersOverride],
  );

  const groupSubtitle = useMemo(() => {
    if (!meta.isGroup) {
      return `${meta.enterprise} · ${meta.isOnline ? 'Online' : 'Offline'}`;
    }

    const others = meta.members.filter((name) => name !== 'You');
    if (others.length === 0) return 'Group · tap for info';
    if (others.length <= 2) return others.join(', ');
    return `${others.slice(0, 2).join(', ')} and ${others.length - 2} more`;
  }, [meta.enterprise, meta.isGroup, meta.isOnline, meta.members]);

  const [draft, setDraft] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(() =>
    isLiveConversation ? [] : initialMessages,
  );
  const [apiConversation, setApiConversation] = useState<Conversation | null>(null);
  const [isLoadingConversation, setIsLoadingConversation] = useState(isLiveConversation);
  const [isLoadingMessages, setIsLoadingMessages] = useState(isLiveConversation);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [showTyping, setShowTyping] = useState(
    mode === 'full' && !isNewGroup && !isLiveConversation,
  );
  const [showSearch, setShowSearch] = useState(false);
  const [highlightedMessageId, setHighlightedMessageId] = useState<string | null>(null);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [hasOlder, setHasOlder] = useState(meta.hasOlderMessages);
  const voiceRecorder = useVoiceRecorder();
  const { openCamera } = useChatCamera();
  const listRef = useRef<FlatList>(null);
  const extraContentPadding = useSharedValue(0);
  const [composerBlockHeight, setComposerBlockHeight] = useState(CHAT_COMPOSER_BASE_HEIGHT);
  const shouldStickToBottomRef = useRef(true);
  const contentSizeScrollTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [viewerImageUri, setViewerImageUri] = useState<string | null>(null);

  const previewLimitReached = meta.mode === 'preview' && meta.previewUsed >= meta.previewLimit;
  const canSend = meta.mode === 'full' || (meta.mode === 'preview' && !previewLimitReached);
  const inputDisabled = !canSend || apiConversation?.is_read_only === true;
  const showFullFeatures = meta.mode === 'full';

  const currentUserId = useAuthStore((state) => state.user?.id) ?? DEV_USER.user_id;

  const [isProviderOnline, setIsProviderOnline] = useState(meta.isOnline);

  const [selectedEditMessage, setSelectedEditMessage] = useState<ChatMessage | null>(null);
  const [editMenuOpen, setEditMenuOpen] = useState(false);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingPreviewText, setEditingPreviewText] = useState('');
  const [composerFocusKey, setComposerFocusKey] = useState(0);

  const canEditSelectedMessage = Boolean(
    selectedEditMessage &&
      !editingMessageId &&
      isLiveConversation &&
      selectedEditMessage.sender === 'user' &&
      selectedEditMessage.messageType !== 'deleted' &&
      (selectedEditMessage.messageType === 'text' ||
        selectedEditMessage.messageType === 'markdown' ||
        !selectedEditMessage.messageType),
  );

  const canDeleteSelectedMessage = Boolean(
    selectedEditMessage &&
      !editingMessageId &&
      isLiveConversation &&
      selectedEditMessage.sender === 'user' &&
      selectedEditMessage.messageType !== 'deleted',
  );

  const canShowMessageMenu = canEditSelectedMessage || canDeleteSelectedMessage;

  const clearMessageSelection = useCallback(() => {
    setEditMenuOpen(false);
    setSelectedEditMessage(null);
  }, []);

  const cancelEdit = useCallback(() => {
    setEditingMessageId(null);
    setEditingPreviewText('');
    setDraft('');
    Keyboard.dismiss();
  }, []);

  const isEditMode = Boolean(editingMessageId);

  useEffect(() => {
    if (!selectedEditMessage || editingMessageId) return;

    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      clearMessageSelection();
      return true;
    });

    return () => subscription.remove();
  }, [clearMessageSelection, editingMessageId, selectedEditMessage]);

  useEffect(() => {
    if (!editingMessageId) return;

    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      cancelEdit();
      return true;
    });

    return () => subscription.remove();
  }, [cancelEdit, editingMessageId]);

  const otherUserId = useMemo(() => {
    if (!apiConversation || meta.isGroup) return null;
    const participants = Array.isArray(apiConversation.participants) ? apiConversation.participants : [];
    return participants.find((p) => p.user_id !== currentUserId)?.user_id ?? null;
  }, [apiConversation, currentUserId, meta.isGroup]);

  const typingGetEnabled = API_CONFIG.TYPING_GET_ENABLED && !API_CONFIG.SOCKET_ENABLED;
  const typingPutEnabled = API_CONFIG.TYPING_PUT_ENABLED && !API_CONFIG.SOCKET_ENABLED;
  const socketTypingEnabled = API_CONFIG.SOCKET_ENABLED;

  const { stopTyping } = useConversationTyping({
    conversationId,
    draft,
    enabled:
      (socketTypingEnabled || typingPutEnabled) && isLiveConversation && !inputDisabled && !editingMessageId,
    useSocket: socketTypingEnabled,
  });

  const { isAnyoneTyping: socketAnyoneTyping } = useSocketTyping({
    conversationId,
    currentUserId,
    enabled: socketTypingEnabled && isLiveConversation,
  });

  const { isAnyoneTyping: restAnyoneTyping } = useRemoteTypingUsers({
    conversationId,
    currentUserId,
    enabled: typingGetEnabled && isLiveConversation,
  });

  const isAnyoneTyping = socketTypingEnabled ? socketAnyoneTyping : restAnyoneTyping;

  useConversationRoom({
    conversationId,
    enabled: isLiveConversation,
  });

  const typingIndicatorName = useMemo(() => {
    if (!isLiveConversation) return meta.provider;

    const typingParticipant = apiConversation?.participants.find(
      (participant) => participant.user_id !== currentUserId,
    );

    if (typingParticipant?.role === 'provider') {
      return provider ?? meta.provider ?? 'Provider';
    }

    if (typingParticipant?.role) {
      return typingParticipant.role.charAt(0).toUpperCase() + typingParticipant.role.slice(1);
    }

    return provider ?? meta.provider ?? 'Someone';
  }, [
    apiConversation?.participants,
    currentUserId,
    isLiveConversation,
    meta.provider,
    provider,
  ]);

  const showTypingIndicator = isLiveConversation
    ? isAnyoneTyping
    : showTyping && meta.isOnline;

  const headerTitle = apiConversation?.subject ?? (meta.isGroup ? meta.title : meta.provider);
  const headerSubtitle = isLiveConversation
    ? `${apiConversation?.status ?? 'loading'} · ${enterprise ?? meta.enterprise}`
    : groupSubtitle;

  useEffect(() => {
    if (!isLiveConversation) return undefined;

    let cancelled = false;

    setIsLoadingConversation(true);
    void fetchConversationById(conversationId)
      .then((data) => {
        if (!cancelled) {
          console.log("data", data);
          setApiConversation(data);
        }
      })
      .catch((error) => {
        if (__DEV__) {
          console.warn('⚠️ Conversation details failed:', error);
        }
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoadingConversation(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [conversationId, isLiveConversation]);

  useEffect(() => {
    if (!isLiveConversation) {
      setMessages(initialMessages);
      setHasOlder(meta.hasOlderMessages);
      setNextCursor(null);
      setIsLoadingMessages(false);
      return undefined;
    }

    let cancelled = false;

    setMessages([]);
    setIsLoadingMessages(true);
    setHasOlder(false);
    setNextCursor(null);

    const currentUserId = useAuthStore.getState().user?.id ?? DEV_USER.user_id;

    void fetchConversationMessages(conversationId, { limit: 50 })
      .then(async (response) => {
        if (cancelled) return;

        const hydrated = await hydrateChatMessagesFromApi(response.items, currentUserId);
        if (cancelled) return;

        shouldStickToBottomRef.current = true;
        setMessages(hydrated);
        setNextCursor(response.pagination.next_cursor);
        setHasOlder(response.pagination.has_more);

        if (API_CONFIG.SOCKET_ENABLED) {
          const unreadIncoming = response.items.filter(
            (message) =>
              message.sender_id !== currentUserId &&
              !message.is_deleted &&
              !message.read_by.includes(currentUserId),
          );
          const latestUnread = unreadIncoming.at(-1);

          if (latestUnread) {
            void markMessageReadViaSocket(latestUnread.id);
          }
        }
      })
      .catch((error) => {
        if (__DEV__) {
          console.warn('⚠️ Conversation messages failed:', error);
        }
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoadingMessages(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [conversationId, initialMessages, isLiveConversation, meta.hasOlderMessages]);

  useFocusEffect(
    useCallback(() => {
      if (!isLiveConversation) return undefined;
      if (!API_CONFIG.SOCKET_ENABLED) return undefined;

      const socket = getSocket();
      if (!socket) return undefined;

      const unsubscribeNewMessage = subscribeToNewMessageEvents((apiMessage) => {
        if (apiMessage.conversation_id !== conversationId) return;

        setMessages((prev) => {
          if (prev.some((m) => m.id === apiMessage.id)) return prev;
          if (
            apiMessage.attachment_id &&
            prev.some((m) => m.attachmentId === apiMessage.attachment_id)
          ) {
            return prev;
          }
          return [...prev, mapApiMessageToChatMessage(apiMessage, currentUserId)];
        });

        if (apiMessage.attachment_id && !apiMessage.is_deleted) {
          void hydrateSingleChatMessageFromApi(apiMessage, currentUserId).then((hydrated) => {
            setMessages((prev) => prev.map((m) => (m.id === hydrated.id ? hydrated : m)));
          });
        }

        // Mark received messages as read so the other party sees read status quickly.
        if (apiMessage.sender_id !== currentUserId && !apiMessage.is_deleted) {
          void markMessageReadViaSocket(apiMessage.id);
        }
      });

      const onMessageRead = (payload: unknown) => {
        if (!payload || typeof payload !== 'object') return;

        const obj = payload as Record<string, unknown>;
        const messageId =
          typeof obj.message_id === 'string'
            ? obj.message_id
            : typeof (obj as { message?: { id?: unknown } }).message?.id === 'string'
              ? (obj as { message?: { id?: unknown } }).message?.id
              : null;
        const userId = typeof obj.user_id === 'string' ? obj.user_id : null;

        if (!messageId || !userId) return;

        setMessages((prev) =>
          prev.map((m) => {
            if (m.id !== messageId) return m;

            // Only update read receipts for messages you sent (outgoing).
            // message_read payload user_id = who read the message.
            if (m.sender !== 'user') return m;
            if (userId === currentUserId) return m; // I'm the reader => don't affect my outgoing bubble.

            return { ...m, status: 'read' };
          }),
        );
      };

      const onConversationUpdated = (payload: unknown) => {
        if (!payload || typeof payload !== 'object') return;

        const obj = payload as Record<string, unknown>;
        const maybeConversation =
          obj.conversation ?? (obj as { data?: { conversation?: unknown } }).data?.conversation ?? obj;

        if (
          maybeConversation &&
          typeof maybeConversation === 'object' &&
          typeof (maybeConversation as { id?: unknown }).id === 'string'
        ) {
          // Socket payload may be partial (e.g. missing `participants`).
          // Keep existing `participants`/known fields when missing.
          setApiConversation((prev) => {
            if (!prev) return maybeConversation as Conversation;
            const partial = maybeConversation as Partial<Conversation>;
            return {
              ...prev,
              ...partial,
              participants: partial.participants ?? prev.participants,
            };
          });
        }
      };

      const onUserOnline = (payload: unknown) => {
        if (!payload || typeof payload !== 'object') return;
        const obj = payload as Record<string, unknown>;
        const userId = typeof obj.user_id === 'string' ? obj.user_id : null;
        if (!userId || userId !== otherUserId) return;
        setIsProviderOnline(true);
      };

      const onUserOffline = (payload: unknown) => {
        if (!payload || typeof payload !== 'object') return;
        const obj = payload as Record<string, unknown>;
        const userId = typeof obj.user_id === 'string' ? obj.user_id : null;
        if (!userId || userId !== otherUserId) return;
        setIsProviderOnline(false);
      };

      const onSocketError = (payload: unknown) => {
        // Keep UI stable; just log socket validation/auth errors.
        if (__DEV__) {
          console.warn('[Socket ERROR event]', payload);
        }
      };

      socket.on(SOCKET_SERVER_EVENTS.MESSAGE_READ, onMessageRead);
      socket.on(SOCKET_SERVER_EVENTS.CONVERSATION_UPDATED, onConversationUpdated);
      socket.on(SOCKET_SERVER_EVENTS.USER_ONLINE, onUserOnline);
      socket.on(SOCKET_SERVER_EVENTS.USER_OFFLINE, onUserOffline);
      socket.on(SOCKET_SERVER_EVENTS.ERROR, onSocketError);

      return () => {
        unsubscribeNewMessage();
        socket.off(SOCKET_SERVER_EVENTS.MESSAGE_READ, onMessageRead);
        socket.off(SOCKET_SERVER_EVENTS.CONVERSATION_UPDATED, onConversationUpdated);
        socket.off(SOCKET_SERVER_EVENTS.USER_ONLINE, onUserOnline);
        socket.off(SOCKET_SERVER_EVENTS.USER_OFFLINE, onUserOffline);
        socket.off(SOCKET_SERVER_EVENTS.ERROR, onSocketError);
      };
    }, [conversationId, currentUserId, isLiveConversation, otherUserId]),
  );

  useEffect(() => {
    if (!isLiveConversation) return undefined;

    let cancelled = false;

    void markConversationAsRead(conversationId)
      .then(() => {
        if (!cancelled) {
          setApiConversation((prev) => (prev ? { ...prev, unread_count: 0 } : prev));
        }
      })
      .catch((error) => {
        if (__DEV__) {
          console.warn('⚠️ Mark conversation read failed:', error);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [conversationId, isLiveConversation]);

  const listContentStyle = useMemo(
    () => [
      styles.messageListContent,
      { paddingBottom: CHAT_MESSAGE_COMPOSER_GAP },
    ],
    [],
  );

  const renderScrollComponent = useCallback(
    (props: ScrollViewProps) => (
      <ChatKeyboardScrollView
        {...props}
        composerOffset={composerBlockHeight}
        extraContentPadding={extraContentPadding}
      />
    ),
    [composerBlockHeight, extraContentPadding],
  );

  const handleComposerBlockLayout = useCallback((event: LayoutChangeEvent) => {
    const height = event.nativeEvent.layout.height;
    if (height > 0) {
      setComposerBlockHeight(height);
    }
  }, []);

  const handleComposerLayout = useCallback(
    (event: LayoutChangeEvent) => {
      const height = event.nativeEvent.layout.height;
      extraContentPadding.value = withTiming(
        Math.max(height - CHAT_COMPOSER_BASE_HEIGHT, 0),
        { duration: 200 },
      );
    },
    [extraContentPadding],
  );

  const scrollToEnd = useCallback((animated = false) => {
    if (messages.length === 0) return;
    listRef.current?.scrollToEnd({ animated });
  }, [messages.length]);

  const handleListContentSizeChange = useCallback(() => {
    if (!shouldStickToBottomRef.current || messages.length === 0 || isLoadingMessages) return;

    if (contentSizeScrollTimerRef.current) {
      clearTimeout(contentSizeScrollTimerRef.current);
    }

    contentSizeScrollTimerRef.current = setTimeout(() => {
      listRef.current?.scrollToEnd({ animated: false });
    }, 50);
  }, [isLoadingMessages, messages.length]);

  const handleListScroll = useCallback(
    (event: {
      nativeEvent: {
        contentOffset: { y: number };
        contentSize: { height: number };
        layoutMeasurement: { height: number };
      };
    }) => {
      const { contentOffset, contentSize, layoutMeasurement } = event.nativeEvent;
      const distanceFromBottom =
        contentSize.height - layoutMeasurement.height - contentOffset.y;

      if (distanceFromBottom > 80) {
        shouldStickToBottomRef.current = false;
      }
    },
    [],
  );

  const handleScrollToIndexFailed = useCallback(
    (info: { index: number; averageItemLength: number }) => {
      listRef.current?.scrollToOffset({
        offset: info.averageItemLength * info.index,
        animated: false,
      });

      setTimeout(() => {
        if (shouldStickToBottomRef.current) {
          scrollToEnd(false);
        } else {
          listRef.current?.scrollToIndex({
            index: info.index,
            animated: true,
            viewPosition: 0.5,
          });
        }
      }, 120);
    },
    [scrollToEnd],
  );

  useEffect(() => {
    shouldStickToBottomRef.current = true;
  }, [conversationId]);

  useEffect(() => {
    if (isLoadingMessages || messages.length === 0) return undefined;

    shouldStickToBottomRef.current = true;

    const timer = setTimeout(() => {
      scrollToEnd(false);
    }, 250);

    return () => clearTimeout(timer);
  }, [isLoadingMessages, messages.length, scrollToEnd]);

  useEffect(() => {
    return () => {
      if (contentSizeScrollTimerRef.current) {
        clearTimeout(contentSizeScrollTimerRef.current);
      }
    };
  }, []);

  const scrollToMessage = useCallback((messageId: string) => {
    const index = messages.findIndex((message) => message.id === messageId);
    if (index < 0) return;

    setHighlightedMessageId(messageId);
    setTimeout(() => {
      listRef.current?.scrollToIndex({
        index,
        animated: true,
        viewPosition: 0.5,
      });
    }, 100);
    setTimeout(() => setHighlightedMessageId(null), 2000);
  }, [messages]);

  useKeyboardHandler(
    {
      onEnd: (event) => {
        'worklet';
        if (event.height > 0) {
          runOnJS(scrollToEnd)(true);
        }
      },
    },
    [scrollToEnd],
  );

  useEffect(() => {
    return () => {
      void voiceRecorder.cancelRecording();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (Platform.OS !== 'ios') return undefined;

    const showSub = Keyboard.addListener('keyboardWillShow', () => {
      scrollToEnd(true);
    });

    return () => {
      showSub.remove();
    };
  }, [scrollToEnd]);

  useEffect(() => {
    if (messages.length > 0 && shouldStickToBottomRef.current && !isLoadingMessages) {
      scrollToEnd(false);
    }
  }, [messages.length, showTypingIndicator, isLoadingMessages, scrollToEnd]);

  useEffect(() => {
    if (!viewerImageUri) return undefined;

    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      setViewerImageUri(null);
      return true;
    });

    return () => subscription.remove();
  }, [viewerImageUri]);

  const handleSendVoice = async () => {
    setSelectedEditMessage(null);
    const result = await voiceRecorder.finishRecording();
    if (!result) return;

    // For live conversations, upload and rely on the socket `new_message` event.
    if (isLiveConversation) {
      try {
        setIsSending(true);

        const fileName = `voice-${Date.now()}.m4a`;
        await uploadAndSendAttachmentMessage({
          conversationId,
          fileUri: result.uri,
          fileName,
          mimeType: 'audio/m4a',
          attachmentType: 'audio',
        });
      } catch (error) {
        if (__DEV__) console.warn('[Attachment upload] voice failed:', error);
        Alert.alert('Upload failed', 'Could not upload voice message.');
      } finally {
        setIsSending(false);
      }

      return;
    }

    // Preview / readonly: show local voice bubble immediately.
    setMessages((prev) => [
      ...prev,
      {
        id: `voice-${Date.now()}`,
        sender: 'user',
        timestamp: 'Just now',
        status: 'sent',
        messageType: 'voice',
        voice: {
          duration: result.durationLabel,
          transcript: 'Voice message',
          uri: result.uri,
        },
      },
    ]);
    setShowTyping(true);
    scrollToEnd(true);
  };

  const handleCameraPhoto = async () => {
    if (inputDisabled || isSending) return;
    setSelectedEditMessage(null);
    const photo = await openCamera();
    if (!photo) return;

    if (isLiveConversation) {
      try {
        setIsSending(true);
        await uploadAndSendAttachmentMessage({
          conversationId,
          fileUri: photo.uri,
          fileName: photo.fileName,
          mimeType: undefined,
          attachmentType: 'image',
        });
      } catch (error) {
        if (__DEV__) console.warn('[Attachment upload] image failed:', error);
        Alert.alert('Upload failed', 'Could not upload image.');
      } finally {
        setIsSending(false);
      }
      return;
    }

    // Preview / readonly: show local image bubble immediately.
    setMessages((prev) => [
      ...prev,
      {
        id: `photo-${Date.now()}`,
        sender: 'user',
        timestamp: 'Just now',
        status: 'sent',
        messageType: 'attachment',
        attachment: {
          type: 'image',
          name: photo.fileName,
          size: photo.fileSizeLabel,
          thumbnail: photo.uri,
          storage: 'S3',
        },
      },
    ]);
    scrollToEnd(true);
  };

  const handleDocumentPick = async () => {
    if (inputDisabled || isSending) return;
    setSelectedEditMessage(null);

    const result = await DocumentPicker.getDocumentAsync({
      type: '*/*',
      copyToCacheDirectory: true,
      multiple: false,
      base64: true,
    });

    if (result.canceled || !result.assets?.[0]) return;

    const asset = result.assets[0];
    const fileUri = asset.base64
      ? `data:${asset.mimeType ?? 'application/octet-stream'};base64,${asset.base64}`
      : asset.uri;
    const fileName = asset.name ?? `file-${Date.now()}`;
    const mimeType = asset.mimeType;
    const fileSizeLabel = typeof asset.size === 'number' ? `${Math.max(1, Math.round(asset.size / 1024))} KB` : '—';

    const attachmentTypeForBackend =
      mimeType?.startsWith('image/') ? 'image' : mimeType?.startsWith('audio/') ? 'audio' : mimeType?.startsWith('video/') ? 'video' : 'document';

    if (isLiveConversation) {
      try {
        setIsSending(true);
        await uploadAndSendAttachmentMessage({
          conversationId,
          fileUri,
          fileName,
          mimeType,
          attachmentType: attachmentTypeForBackend,
        });
      } catch (error) {
        if (__DEV__) console.warn('[Attachment upload] document failed:', error);
        Alert.alert('Upload failed', 'Could not upload attachment.');
      } finally {
        setIsSending(false);
      }
      return;
    }

    // Preview / readonly: add a local attachment bubble immediately.
    const lowerMime = (mimeType ?? '').toLowerCase();
    const attachmentTypeForUI =
      lowerMime.includes('pdf') ? 'pdf' : lowerMime.includes('word') || lowerMime.includes('docx') ? 'word' : lowerMime.startsWith('image/') ? 'image' : attachmentTypeForBackend === 'audio' ? 'audio' : attachmentTypeForBackend === 'video' ? 'video' : 'pdf';

    setMessages((prev) => [
      ...prev,
      {
        id: `doc-${Date.now()}`,
        sender: 'user',
        timestamp: 'Just now',
        status: 'sent',
        messageType: 'attachment',
        attachment: {
          type: attachmentTypeForUI as any,
          name: fileName,
          size: fileSizeLabel,
          thumbnail: lowerMime.startsWith('image/') ? fileUri : undefined,
          storage: 'S3',
        },
      },
    ]);

    setTimeout(() => scrollToEnd(true), 0);
  };

  const voiceControls = {
    state: voiceRecorder.state,
    startRecording: voiceRecorder.startRecording,
    togglePauseResume: voiceRecorder.togglePauseResume,
    togglePreviewPlayback: voiceRecorder.togglePreviewPlayback,
    cancelRecording: voiceRecorder.cancelRecording,
    finishRecording: handleSendVoice,
    formatTime: voiceRecorder.formatTime,
  };

  const handleSend = async () => {
    const text = draft.trim();
    if (!text || inputDisabled || isSending) return;

    if (editingMessageId && isLiveConversation) {
      try {
        stopTyping();
        setIsSending(true);

        const updated = await editMessage(editingMessageId, text);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === updated.id ? mapApiMessageToChatMessage(updated, currentUserId) : m,
          ),
        );

        setDraft('');
        setEditingPreviewText('');
        setSelectedEditMessage(null);
        setEditingMessageId(null);
        setShowTyping(true);
      } catch (error) {
        if (__DEV__) console.warn('[Edit] Failed:', error);
        Alert.alert('Edit failed', 'Could not edit message. Please try again.');
        setDraft(text);
      } finally {
        setIsSending(false);
      }
      return;
    }

    if (!isLiveConversation) {
      setMessages((prev) => [
        ...prev,
        {
          id: `user-${Date.now()}`,
          text,
          sender: 'user',
          timestamp: 'Just now',
          status: 'sent',
          messageType: 'text',
        },
      ]);
      setDraft('');
      setShowTyping(true);
      return;
    }

    stopTyping();
    setDraft('');
    setIsSending(true);

    try {
      const currentUserId = useAuthStore.getState().user?.id ?? DEV_USER.user_id;
      const sentMessage = await sendMessageViaSocket({
        content: text,
        conversation_id: conversationId,
        message_type: 'text',
      });

      // Socket path: wait for `new_message` — do not append locally (avoids duplicate bubbles).
      if (!API_CONFIG.SOCKET_ENABLED || !isSocketConnected()) {
        setMessages((prev) => {
          if (prev.some((m) => m.id === sentMessage.id)) return prev;
          return [...prev, mapApiMessageToChatMessage(sentMessage, currentUserId)];
        });
      } else {
        shouldStickToBottomRef.current = true;
      }

      scrollToEnd(true);
    } catch (error) {
      setDraft(text);

      const message =
        error && typeof error === 'object' && 'message' in error
          ? String((error as { message: string }).message)
          : 'Could not send message. Please try again.';

      Alert.alert('Send failed', message);
    } finally {
      setIsSending(false);
    }
  };

  const handleDeleteMessage = async (messageId: string) => {
    if (!isLiveConversation) return;

    try {
      await deleteMessage(messageId);

      setMessages((prev) =>
        prev.map((message) =>
          message.id === messageId
            ? {
                ...message,
                messageType: 'deleted',
                text: 'This message was deleted',
              }
            : message,
        ),
      );
    } catch (error) {
      const message =
        error && typeof error === 'object' && 'message' in error
          ? String((error as { message: string }).message)
          : 'Could not delete message. Please try again.';

      Alert.alert('Delete failed', message);
    }
  };

  const confirmDeleteSelectedMessage = () => {
    if (!selectedEditMessage) return;

    const messageId = selectedEditMessage.id;

    Alert.alert('Delete message', 'This message will be removed for everyone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          setEditMenuOpen(false);
          setSelectedEditMessage(null);
          void handleDeleteMessage(messageId);
        },
      },
    ]);
  };

  const openMessageMenu = (message: ChatMessage) => {
    if (!isLiveConversation || message.sender !== 'user' || message.messageType === 'deleted') {
      return;
    }

    setSelectedEditMessage(message);
    setEditMenuOpen(true);
  };

  const beginInlineEdit = (message?: ChatMessage) => {
    const target = message ?? selectedEditMessage;
    if (!target) return;

    const text = target.text ?? '';
    const messageId = target.id;

    setEditMenuOpen(false);
    setSelectedEditMessage(null);
    setEditingMessageId(messageId);
    setEditingPreviewText(text);
    setDraft(text);

    requestAnimationFrame(() => {
      setComposerFocusKey((key) => key + 1);
      scrollToEnd(true);
    });
  };

  const handleLoadOlder = () => {
    if (isLiveConversation) {
      if (!nextCursor || loadingOlder) return;

      setLoadingOlder(true);
      const currentUserId = useAuthStore.getState().user?.id ?? DEV_USER.user_id;

      void fetchConversationMessages(conversationId, { cursor: nextCursor, limit: 50 })
        .then(async (response) => {
          const olderMessages = await hydrateChatMessagesFromApi(response.items, currentUserId);

          setMessages((prev) => {
            const existingIds = new Set(prev.map((message) => message.id));
            const uniqueOlder = olderMessages.filter((message) => !existingIds.has(message.id));
            return [...uniqueOlder, ...prev];
          });
          setNextCursor(response.pagination.next_cursor);
          setHasOlder(response.pagination.has_more);
        })
        .catch((error) => {
          if (__DEV__) {
            console.warn('⚠️ Older messages failed:', error);
          }
        })
        .finally(() => {
          setLoadingOlder(false);
        });

      return;
    }

    setLoadingOlder(true);
    setTimeout(() => {
      setMessages((prev) => [
        {
          id: `older-${Date.now()}`,
          text: 'Older message loaded from history',
          sender: 'provider',
          timestamp: 'Last week',
          messageType: 'text',
        },
        ...prev,
      ]);
      setHasOlder(false);
      setLoadingOlder(false);
    }, 600);
  };

  const chatBody = (
    <View style={styles.chatArea}>
      <View style={styles.messageListWrap}>
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <ChatMessageItem
              message={item}
              isGroup={meta.isGroup}
              onDeleteMessage={isLiveConversation ? handleDeleteMessage : undefined}
              onImagePress={setViewerImageUri}
              onLongPressMessage={openMessageMenu}
              selectedForEdit={
                selectedEditMessage?.id === item.id || highlightedMessageId === item.id
              }
            />
          )}
          style={styles.messageList}
          contentContainerStyle={listContentStyle}
          renderScrollComponent={renderScrollComponent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="always"
          keyboardDismissMode="none"
          scrollEnabled={!isEditMode}
          pointerEvents={isEditMode ? 'none' : 'auto'}
          onContentSizeChange={handleListContentSizeChange}
          onScroll={handleListScroll}
          scrollEventThrottle={16}
          initialNumToRender={Math.min(messages.length, 50)}
          maxToRenderPerBatch={24}
          windowSize={15}
          onScrollToIndexFailed={handleScrollToIndexFailed}
          ListHeaderComponent={
            hasOlder ? (
              loadingOlder ? (
                <ActivityIndicator color={PRIMARY} style={styles.loader} />
              ) : (
                <ChatLoadOlder cursor={nextCursor ?? meta.olderCursor} onLoad={handleLoadOlder} />
              )
            ) : isLoadingMessages ? (
              <ActivityIndicator color={PRIMARY} style={styles.loader} />
            ) : null
          }
          ListEmptyComponent={
            !isLoadingMessages ? (
              <Text style={styles.emptyMessagesText}>No messages yet</Text>
            ) : null
          }
          ListFooterComponent={
            showTypingIndicator ? <TypingIndicator name={typingIndicatorName} /> : null
          }
        />

        {isEditMode ? <View style={styles.editDimOverlay} pointerEvents="none" /> : null}
      </View>

      {isEditMode && editingPreviewText.trim().length > 0 ? (
        <View style={styles.editPreviewContainer}>
          <View style={styles.editPreviewBubble}>
            <Text style={styles.editPreviewText} numberOfLines={4}>
              {editingPreviewText}
            </Text>
          </View>
        </View>
      ) : null}
    </View>
  );

  const composerNode = (
    <KeyboardStickyView offset={{ opened: CHAT_COMPOSER_GAP }}>
      <View
        style={[styles.composer, isEditMode && styles.composerEditMode]}
        onLayout={handleComposerBlockLayout}
      >
        <View onLayout={handleComposerLayout}>
          {inputDisabled ? (
            <View style={styles.composerDisabled}>
              <Text style={styles.composerDisabledText}>
                {meta.mode === 'readonly'
                  ? 'Chat closed · Book again to start a new conversation'
                  : 'Message limit reached · Book this service to continue'}
              </Text>
            </View>
          ) : (
            <ChatComposer
              draft={draft}
              onChangeDraft={setDraft}
              onSend={() => void handleSend()}
              voice={voiceControls}
              onInputFocus={() => scrollToEnd(true)}
              onAttach={() => void handleDocumentPick()}
              onCameraPress={() => void handleCameraPhoto()}
              focusRequestKey={composerFocusKey}
              inputSessionKey={editingMessageId ?? 'compose'}
              editMode={isEditMode}
            />
          )}
        </View>
      </View>
    </KeyboardStickyView>
  );


  return (
    <View style={styles.screen}>
    <AppStatusBar />
    <StatusBarFill />
      {isEditMode ? (
        <View style={[styles.editModeHeader, { paddingTop: 12 }]}>
          <Pressable
            onPress={cancelEdit}
            style={({ pressed }) => [styles.editModeBackBtn, pressed && styles.pressed]}
            hitSlop={8}
          >
            <ChevronLeftIcon size={22} color="#FFFFFF" />
          </Pressable>
          <Text style={styles.editModeHeaderTitle}>Edit message</Text>
        </View>
      ) : (
        <View style={[styles.header, { paddingTop: 12 }]}>
          <Pressable
            onPress={() => {
              if (selectedEditMessage) {
                clearMessageSelection();
                return;
              }
              setEditMenuOpen(false);
              setSelectedEditMessage(null);
              router.back();
            }}
            style={({ pressed }) => [styles.backBtn, pressed && styles.pressed]}
            hitSlop={8}
          >
            <ChevronLeftIcon size={22} color={TEXT_BLACK} />
          </Pressable>

          <ProviderAvatar initial={meta.avatarInitial} isGroup={meta.isGroup} />

          <View style={styles.headerInfo}>
            <View style={styles.headerTitleRow}>
              <Text style={styles.headerTitle} numberOfLines={1}>
                {headerTitle}
              </Text>     
              {isLoadingConversation ? (
                <ActivityIndicator size="small" color={PRIMARY} style={styles.headerLoader} />
              ) : !meta.isGroup ? (
                <ChatLiveBadge isOnline={isLiveConversation ? isProviderOnline : meta.isOnline} />
              ) : null}
            </View>
            <Text style={styles.headerSubtitle} numberOfLines={1}>
              {headerSubtitle}
            </Text>
          </View>

          <Pressable
            onPress={() => setShowSearch(!showSearch)}
            style={({ pressed }) => [styles.headerActionBtn, pressed && styles.pressed]}
            hitSlop={8}
          >
            <Ionicons name="search-outline" size={22} color={TEXT_BLACK} />
          </Pressable>

          {meta.isGroup ? (
            <Pressable
              style={({ pressed }) => [styles.headerActionBtn, pressed && styles.pressed]}
              hitSlop={8}
            >
              <Ionicons name="ellipsis-vertical" size={22} color={TEXT_BLACK} />
            </Pressable>
          ) : canShowMessageMenu ? (
            <Pressable
              style={({ pressed }) => [styles.headerActionBtn, pressed && styles.pressed]}
              hitSlop={8}
              onPress={() => setEditMenuOpen(true)}
            >
              <Ionicons name="ellipsis-vertical" size={22} color={TEXT_BLACK} />
            </Pressable>
          ) : null}
        </View>
      )}

      {!isEditMode ? (
        <ChatSearchPanel
          visible={showSearch}
          conversationId={conversationId}
          enabled={isLiveConversation}
          onClose={() => setShowSearch(false)}
          onJumpToMessage={scrollToMessage}
        />
      ) : null}
      {!isEditMode && !isNewGroup && meta.isGroup ? <ChatGroupMembers members={meta.members} /> : null}

      {!isEditMode && !isNewGroup ? (
        <ChatBanner
          mode={meta.mode}
          previewUsed={meta.previewUsed}
          previewLimit={meta.previewLimit}
          planUsed={meta.planUsed}
          planLimit={meta.planLimit}
          planName={meta.planName}
          loadedCount={messages.length}
        />
      ) : null}

      {showFullFeatures && !isNewGroup && !isEditMode ? <ChatAiSummaryCard /> : null}

      <SafeAreaView edges={['bottom']} style={styles.flex}>
        {chatBody}
        {composerNode}
      </SafeAreaView>

      {editMenuOpen && selectedEditMessage && canShowMessageMenu ? (
        <Modal
          visible={editMenuOpen}
          transparent
          animationType="fade"
          onRequestClose={() => setEditMenuOpen(false)}
        >
          <View style={styles.menuOverlay}>
            <Pressable style={styles.menuBackdrop} onPress={() => setEditMenuOpen(false)} />
            <View
              style={[
                styles.editDropdown,
                { top: insets.top + 52, right: H_PAD, zIndex: 10, elevation: 10 },
              ]}
            >
              {canEditSelectedMessage ? (
                <Pressable
                  style={styles.editDropdownItem}
                  onPress={() => beginInlineEdit(selectedEditMessage)}
                >
                  <Text style={styles.editDropdownItemText}>Edit</Text>
                </Pressable>
              ) : null}
              {canDeleteSelectedMessage ? (
                <Pressable
                  style={styles.editDropdownItem}
                  onPress={confirmDeleteSelectedMessage}
                >
                  <Text style={styles.editDropdownDeleteText}>Delete</Text>
                </Pressable>
              ) : null}
            </View>
          </View>
        </Modal>
      ) : null}

      {viewerImageUri ? (
        <ChatImageViewer uri={viewerImageUri} onClose={() => setViewerImageUri(null)} />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BODY_BG },
  flex: { flex: 1 },
  chatArea: { flex: 1 },
  messageListWrap: {
    flex: 1,
    position: 'relative',
  },
  editDimOverlay: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(0,0,0,0.45)',
  },
  editPreviewContainer: {
    paddingHorizontal: H_PAD,
    paddingTop: 8,
    paddingBottom: 4,
    alignItems: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.45)',
  },
  editPreviewBubble: {
    backgroundColor: PRIMARY,
    borderRadius: 16,
    borderBottomRightRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 10,
    maxWidth: '78%',
  },
  editPreviewText: {
    color: '#FFFFFF',
    fontSize: isSmallDevice ? 14 : 15,
    lineHeight: 20,
    fontWeight: '500',
  },
  composerEditMode: {
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderTopWidth: 0,
  },
  editModeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: H_PAD,
    paddingBottom: isSmallDevice ? 10 : 12,
    backgroundColor: PRIMARY,
  },
  editModeBackBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  editModeHeaderTitle: {
    fontSize: isSmallDevice ? 17 : 18,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: isSmallDevice ? 10 : 12,
    paddingHorizontal: H_PAD,
    paddingBottom: isSmallDevice ? 10 : 12,
    backgroundColor: PAGE_BG,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
    ...shadowSm,
  },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: BODY_BG,
  },
  headerInfo: { flex: 1, minWidth: 0 },
  headerTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  headerLoader: { marginLeft: 2 },
  headerTitle: {
    fontSize: isSmallDevice ? 15 : 16,
    fontWeight: '800',
    color: TEXT_BLACK,
    flexShrink: 1,
  },
  headerSubtitle: {
    fontSize: isSmallDevice ? 11 : 12,
    fontWeight: '500',
    color: TEXT_DESC,
    marginTop: 1,
  },
  headerActionBtn: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { fontWeight: '800', color: '#FFFFFF', fontSize: isSmallDevice ? 15 : 16, zIndex: 1 },
  banner: {
    paddingHorizontal: H_PAD,
    paddingVertical: isSmallDevice ? 8 : 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
  },
  bannerInfo: { backgroundColor: '#F0FDF4' },
  bannerWarning: { backgroundColor: '#FFF7ED' },
  bannerMuted: { backgroundColor: '#F3F4F6' },
  bannerTitle: { fontSize: isSmallDevice ? 12 : 13, fontWeight: '800', color: PRIMARY },
  bannerTitleWarning: { color: '#C2410C' },
  bannerDesc: { fontSize: isSmallDevice ? 11 : 12, fontWeight: '500', color: TEXT_DESC, marginTop: 2 },
  bannerDescWarning: { color: '#9A3412' },
  usageRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  usagePct: { fontSize: 11, fontWeight: '700', color: PRIMARY },
  usageTrack: { height: 4, borderRadius: 2, backgroundColor: '#D1FAE5', overflow: 'hidden' },
  usageFill: { height: '100%', borderRadius: 2, backgroundColor: PRIMARY },
  messageList: { flex: 1 },
  messageListContent: {
    paddingHorizontal: H_PAD,
    paddingTop: isSmallDevice ? 8 : 12,
    gap: isSmallDevice ? 4 : 6,
  },
  loader: { marginVertical: 10 },
  emptyMessagesText: {
    textAlign: 'center',
    marginTop: 24,
    fontSize: 14,
    fontWeight: '600',
    color: TEXT_MUTED,
  },
  typingRow: { alignItems: 'flex-start', marginTop: 4 },
  typingBubble: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: PAGE_BG,
    borderRadius: 16,
    borderBottomLeftRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: BORDER,
  },
  typingDots: { flexDirection: 'row', gap: 3 },
  typingDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: TEXT_MUTED, opacity: 0.5 },
  typingDotMid: { opacity: 0.85 },
  typingText: { fontSize: 11, fontWeight: '600', color: TEXT_DESC },
  composer: {
    paddingHorizontal: 6,
    paddingTop: 6,
    paddingBottom: 6,
    backgroundColor: PAGE_BG,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: BORDER,
  },
  menuOverlay: {
    flex: 1,
  },
  menuBackdrop: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(0,0,0,0.25)',
  },
  editDropdown: {
    position: 'absolute',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    minWidth: 168,
    paddingVertical: 6,
    shadowColor: '#000000',
    shadowOpacity: 0.18,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: BORDER,
  },
  editDropdownItem: {
    paddingVertical: 14,
    paddingHorizontal: 20,
  },
  editDropdownItemText: {
    fontSize: 15,
    fontWeight: '600',
    color: TEXT_BLACK,
  },
  editDropdownDeleteText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#EF4444',
  },
  composerDisabled: {
    marginHorizontal: H_PAD - 6,
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
    padding: 12,
    alignItems: 'center',
  },
  composerDisabledText: { fontSize: 12, fontWeight: '600', color: TEXT_DESC, textAlign: 'center' },
  pressed: { opacity: 0.9 },
});
