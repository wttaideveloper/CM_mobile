import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Modal,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AppStatusBar, StatusBarFill } from '@/components/AppStatusBar';
import { ChevronLeftIcon } from '@/components/dashboard/DashboardIcons';
import {
  ARCHIVED_CHAT_COUNT,
  type ChatInboxItem,
} from '@/constants/chatInbox';
import { fetchConversations, searchConversations } from '@/services/conversation.service';
import { chatHref, createGroupHref } from '@/utils/chatNavigation';
import { mapConversationListItemToInbox } from '@/utils/conversation.mapper';
import { shadowSm } from '@/utils/shadows';
import { isSmallDevice } from '@/utils/responsive';

const PRIMARY = '#1F5D4E';
const MINT = '#EAF4EC';
const PAGE_BG = '#FFFFFF';
const BODY_BG = '#F5F7F5';
const TEXT_MUTED = '#9CA3AF';
const TEXT_DESC = '#6B7280';
const TEXT_BLACK = '#111111';
const BORDER = '#E8EDEA';
const CHIP_INACTIVE_BG = '#F3F4F6';
const SEARCH_BORDER = '#E0E7E1';
const H_PAD = isSmallDevice ? 16 : 20;

type InboxFilter = 'All' | 'Unread' | 'Favorites' | 'Groups';

const INBOX_FILTERS: InboxFilter[] = ['All', 'Unread', 'Favorites', 'Groups'];

function Avatar({ item }: { item: ChatInboxItem }) {
  return (
    <View style={[styles.avatar, item.isGroup && styles.avatarGroup]}>
      {item.isGroup ? (
        <Ionicons name="people" size={22} color={PRIMARY} />
      ) : (
        <Text style={styles.avatarText}>{item.avatarInitial}</Text>
      )}
      {item.isOnline ? <View style={styles.onlineDot} /> : null}
    </View>
  );
}

function ChatRow({ item, onPress }: { item: ChatInboxItem; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.chatRow, pressed && styles.pressed]}
    >
      <Avatar item={item} />
      <View style={styles.chatBody}>
        <View style={styles.chatTop}>
          <Text style={styles.chatName} numberOfLines={1}>
            {item.name}
          </Text>
          <Text style={[styles.chatTime, item.unreadCount > 0 && styles.chatTimeUnread]}>
            {item.timestamp}
          </Text>
        </View>
        <View style={styles.chatBottom}>
          <Text style={styles.chatPreview} numberOfLines={1}>
            {item.lastMessage}
          </Text>
          {item.unreadCount > 0 ? (
            <View style={styles.unreadBadge}>
              <Text style={styles.unreadText}>{item.unreadCount}</Text>
            </View>
          ) : null}
        </View>
      </View>
    </Pressable>
  );
}

function FilterChip({
  label,
  count,
  active,
  onPress,
}: {
  label: string;
  count?: number;
  active: boolean;
  onPress: () => void;
}) {
  const displayLabel = count != null && count > 0 ? `${label} ${count}` : label;

  return (
    <Pressable
      onPress={onPress}
      style={[styles.filterChip, active && styles.filterChipActive]}
    >
      <Text style={[styles.filterChipText, active && styles.filterChipTextActive]}>
        {displayLabel}
      </Text>
    </Pressable>
  );
}

export function ChatInboxScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState<InboxFilter>('All');
  const [menuVisible, setMenuVisible] = useState(false);
  const [inboxItems, setInboxItems] = useState<ChatInboxItem[]>([]);
  const [searchResults, setSearchResults] = useState<ChatInboxItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSearching, setIsSearching] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search.trim());
    }, 300);

    return () => clearTimeout(timer);
  }, [search]);

  const loadConversations = useCallback(async (refresh = false) => {
    if (refresh) {
      setIsRefreshing(true);
    } else {
      setIsLoading(true);
    }

    try {
      const response = await fetchConversations({ page: 1, page_size: 20 });
      setInboxItems(response.items.map(mapConversationListItemToInbox));
    } catch (error) {
      if (__DEV__) {
        console.warn('⚠️ Conversations list failed:', error);
      }
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  const runSearch = useCallback(async (query: string) => {
    const q = query.trim();
    if (!q) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);

    try {
      const response = await searchConversations({ q, page: 1, page_size: 20 });
      setSearchResults(response.items.map(mapConversationListItemToInbox));
    } catch (error) {
      if (__DEV__) {
        console.warn('⚠️ Conversation search failed:', error);
      }
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  }, []);

  useEffect(() => {
    void runSearch(debouncedSearch);
  }, [debouncedSearch, runSearch]);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);

    try {
      if (debouncedSearch) {
        await runSearch(debouncedSearch);
      } else {
        const response = await fetchConversations({ page: 1, page_size: 20 });
        setInboxItems(response.items.map(mapConversationListItemToInbox));
      }
    } catch (error) {
      if (__DEV__) {
        console.warn('⚠️ Conversations refresh failed:', error);
      }
    } finally {
      setIsRefreshing(false);
    }
  }, [debouncedSearch, runSearch]);

  useFocusEffect(
    useCallback(() => {
      void loadConversations();
    }, [loadConversations]),
  );

  const unreadCount = useMemo(
    () => inboxItems.reduce((sum, chat) => sum + chat.unreadCount, 0),
    [inboxItems],
  );
  const groupCount = useMemo(
    () => inboxItems.filter((chat) => chat.isGroup).length,
    [inboxItems],
  );

  const chats = useMemo(() => {
    const list = debouncedSearch ? searchResults : inboxItems;

    if (activeFilter === 'Unread') {
      return list.filter((chat) => chat.unreadCount > 0);
    }
    if (activeFilter === 'Favorites') {
      return list.filter((chat) => chat.isFavorite);
    }
    if (activeFilter === 'Groups') {
      return list.filter((chat) => chat.isGroup);
    }

    return list;
  }, [activeFilter, debouncedSearch, inboxItems, searchResults]);

  const isListLoading = debouncedSearch ? isSearching : isLoading;

  const openChat = (item: ChatInboxItem) => {
    router.push(
      chatHref(item.id, {
        mode: item.mode,
        title: item.isGroup ? item.name.replace(' (Group)', '') : item.name,
        provider: item.provider,
        enterprise: item.enterprise,
      }),
    );
  };

  const archivedRow = (
    <Pressable
      style={({ pressed }) => [styles.archivedRow, pressed && styles.pressed]}
      onPress={() => {}}
    >
      <View style={styles.archivedIconWrap}>
        <Ionicons name="archive-outline" size={20} color={TEXT_DESC} />
      </View>
      <Text style={styles.archivedLabel}>Archived</Text>
      {ARCHIVED_CHAT_COUNT > 0 ? (
        <Text style={styles.archivedCount}>{ARCHIVED_CHAT_COUNT}</Text>
      ) : null}
    </Pressable>
  );

  return (
    <View style={styles.screen}>
      <AppStatusBar />
      <StatusBarFill />

      <View style={[styles.topSection, { paddingTop: 12 }]}>
        <View style={styles.titleRow}>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [styles.backBtn, pressed && styles.pressed]}
            hitSlop={8}
          >
            <ChevronLeftIcon size={22} color={PRIMARY} />
          </Pressable>
          <Text style={styles.title}>Chats</Text>
          <Pressable
            onPress={() => setMenuVisible(true)}
            style={({ pressed }) => [styles.menuBtn, pressed && styles.pressed]}
            hitSlop={8}
          >
            <Ionicons name="ellipsis-vertical" size={22} color={PRIMARY} />
          </Pressable>
        </View>

        <View style={styles.searchWrap}>
          <Ionicons name="search-outline" size={18} color={TEXT_MUTED} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search chats"
            placeholderTextColor={TEXT_MUTED}
            value={search}
            onChangeText={setSearch}
            returnKeyType="search"
            autoCorrect={false}
            onSubmitEditing={() => setDebouncedSearch(search.trim())}
          />
        </View>

        <ScrollView
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filtersScroll}
        >
          {INBOX_FILTERS.map((filter) => (
            <FilterChip
              key={filter}
              label={filter}
              count={
                filter === 'Unread'
                  ? unreadCount
                  : filter === 'Groups'
                    ? groupCount
                    : undefined
              }
              active={activeFilter === filter}
              onPress={() => setActiveFilter(filter)}
            />
          ))}
        </ScrollView>
      </View>

      {archivedRow}

      <FlatList
        data={chats}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <ChatRow item={item} onPress={() => openChat(item)} />}
        style={styles.list}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: insets.bottom + 88 },
          chats.length === 0 && !isListLoading && styles.listContentEmpty,
        ]}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        ListEmptyComponent={
          isListLoading ? (
            <ActivityIndicator color={PRIMARY} style={styles.loader} />
          ) : (
            <View style={styles.emptyWrap}>
              <Text style={styles.emptyText}>No chats found</Text>
            </View>
          )
        }
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={() => void handleRefresh()}
            tintColor={PRIMARY}
            colors={[PRIMARY]}
          />
        }
      />

      <Pressable
        onPress={() => router.push(createGroupHref())}
        style={({ pressed }) => [
          styles.fab,
          { bottom: insets.bottom + 20 },
          pressed && styles.pressed,
        ]}
        accessibilityLabel="New chat"
      >
        <Ionicons name="chatbubble-ellipses-outline" size={24} color="#FFFFFF" />
      </Pressable>

      <Modal
        visible={menuVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setMenuVisible(false)}
      >
        <Pressable style={styles.menuBackdrop} onPress={() => setMenuVisible(false)}>
          <View style={[styles.menuCard, { top: insets.top + 52, right: H_PAD }]}>
            <Pressable
              style={({ pressed }) => [styles.menuItem, pressed && styles.pressed]}
              onPress={() => {
                setMenuVisible(false);
                router.push(createGroupHref());
              }}
            >
              <Ionicons name="people-outline" size={20} color={TEXT_BLACK} />
              <Text style={styles.menuItemText}>New group</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.menuItem, pressed && styles.pressed]}
              onPress={() => setMenuVisible(false)}
            >
              <Ionicons name="checkmark-done-outline" size={20} color={TEXT_BLACK} />
              <Text style={styles.menuItemText}>Mark all as read</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.menuItem, pressed && styles.pressed]}
              onPress={() => setMenuVisible(false)}
            >
              <Ionicons name="settings-outline" size={20} color={TEXT_BLACK} />
              <Text style={styles.menuItemText}>Chat settings</Text>
            </Pressable>
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: PAGE_BG,
  },
  topSection: {
    backgroundColor: PAGE_BG,
    paddingHorizontal: H_PAD,
    paddingBottom: isSmallDevice ? 10 : 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: isSmallDevice ? 12 : 14,
  },
  backBtn: {
    width: isSmallDevice ? 32 : 36,
    height: isSmallDevice ? 32 : 36,
    borderRadius: isSmallDevice ? 10 : 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    flex: 1,
    fontSize: isSmallDevice ? 20 : 22,
    lineHeight: 28,
    fontWeight: '800',
    color: TEXT_BLACK,
  },
  menuBtn: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: BODY_BG,
    borderRadius: isSmallDevice ? 16 : 18,
    borderWidth: 1,
    borderColor: SEARCH_BORDER,
    paddingHorizontal: isSmallDevice ? 12 : 16,
    height: isSmallDevice ? 40 : 48,
    marginBottom: isSmallDevice ? 12 : 14,
  },
  searchInput: {
    flex: 1,
    fontSize: isSmallDevice ? 14 : 15,
    lineHeight: 20,
    color: TEXT_BLACK,
    paddingVertical: 0,
  },
  filtersScroll: {
    gap: isSmallDevice ? 8 : 10,
  },
  filterChip: {
    paddingHorizontal: isSmallDevice ? 14 : 16,
    paddingVertical: isSmallDevice ? 8 : 9,
    borderRadius: 20,
    backgroundColor: CHIP_INACTIVE_BG,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  filterChipActive: {
    backgroundColor: MINT,
    borderColor: '#D4E8DA',
  },
  filterChipText: {
    fontSize: isSmallDevice ? 13 : 14,
    lineHeight: 18,
    fontWeight: '600',
    color: TEXT_DESC,
  },
  filterChipTextActive: {
    color: PRIMARY,
    fontWeight: '700',
  },
  list: {
    flex: 1,
    backgroundColor: PAGE_BG,
  },
  listContent: {
    flexGrow: 1,
  },
  listContentEmpty: {
    flexGrow: 1,
  },
  emptyWrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 200,
  },
  loader: {
    marginTop: 40,
  },
  archivedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: H_PAD,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
  },
  archivedIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: CHIP_INACTIVE_BG,
    alignItems: 'center',
    justifyContent: 'center',
  },
  archivedLabel: {
    flex: 1,
    fontSize: 16,
    fontWeight: '700',
    color: TEXT_BLACK,
  },
  archivedCount: {
    fontSize: 14,
    fontWeight: '600',
    color: TEXT_MUTED,
  },
  chatRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: H_PAD,
    paddingVertical: 12,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: MINT,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarGroup: {
    backgroundColor: '#F0FDF4',
  },
  avatarText: {
    fontSize: 18,
    fontWeight: '800',
    color: PRIMARY,
  },
  onlineDot: {
    position: 'absolute',
    right: 2,
    bottom: 2,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#22C55E',
    borderWidth: 2,
    borderColor: PAGE_BG,
  },
  chatBody: {
    flex: 1,
    minWidth: 0,
  },
  chatTop: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  chatName: {
    flex: 1,
    fontSize: 16,
    fontWeight: '700',
    color: TEXT_BLACK,
    marginRight: 8,
  },
  chatTime: {
    fontSize: 12,
    color: TEXT_MUTED,
    fontWeight: '500',
  },
  chatTimeUnread: {
    color: PRIMARY,
    fontWeight: '700',
  },
  chatBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  chatPreview: {
    flex: 1,
    fontSize: 14,
    color: TEXT_DESC,
    fontWeight: '500',
  },
  unreadBadge: {
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: PRIMARY,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 6,
  },
  unreadText: {
    fontSize: 11,
    fontWeight: '800',
    color: '#FFFFFF',
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: BORDER,
    marginLeft: H_PAD + 64,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 14,
    color: TEXT_MUTED,
    fontWeight: '600',
  },
  fab: {
    position: 'absolute',
    right: H_PAD,
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: PRIMARY,
    alignItems: 'center',
    justifyContent: 'center',
    ...shadowSm,
  },
  menuBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  menuCard: {
    position: 'absolute',
    backgroundColor: PAGE_BG,
    borderRadius: 12,
    minWidth: 200,
    paddingVertical: 6,
    ...shadowSm,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  menuItemText: {
    fontSize: 15,
    fontWeight: '600',
    color: TEXT_BLACK,
  },
  pressed: {
    opacity: 0.85,
  },
});
