import * as FileSystem from 'expo-file-system/legacy';
import { Platform } from 'react-native';

type VoiceSegment = {
  uri: string;
  durationSeconds: number;
};

const AMR_HEADER = '#!AMR\n';

function base64ToBytes(base64: string): Uint8Array {
  const binary = globalThis.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i += 1) {
    binary += String.fromCharCode(bytes[i]);
  }
  return globalThis.btoa(binary);
}

export async function mergeVoiceSegments(uris: string[]): Promise<string | null> {
  if (uris.length === 0) {
    return null;
  }

  if (uris.length === 1) {
    return uris[0];
  }

  // Android voice recordings use AMR inside 3gp — append frames after the first header.
  if (Platform.OS !== 'android') {
    return uris[uris.length - 1];
  }

  try {
    const chunks: Uint8Array[] = [];

    for (let index = 0; index < uris.length; index += 1) {
      const base64 = await FileSystem.readAsStringAsync(uris[index], {
        encoding: FileSystem.EncodingType.Base64,
      });
      const bytes = base64ToBytes(base64);

      if (index === 0) {
        chunks.push(bytes);
        continue;
      }

      const header = String.fromCharCode(...bytes.slice(0, 6));
      chunks.push(header === AMR_HEADER ? bytes.slice(6) : bytes);
    }

    const totalLength = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const merged = new Uint8Array(totalLength);
    let offset = 0;

    for (const chunk of chunks) {
      merged.set(chunk, offset);
      offset += chunk.length;
    }

    const cacheDir = FileSystem.cacheDirectory;
    if (!cacheDir) {
      return uris[uris.length - 1];
    }

    const destination = `${cacheDir}voice-merged-${Date.now()}.3gp`;
    await FileSystem.writeAsStringAsync(destination, bytesToBase64(merged), {
      encoding: FileSystem.EncodingType.Base64,
    });

    return destination;
  } catch (error) {
    console.warn('[mergeVoiceSegments] failed:', error);
    return uris[uris.length - 1];
  }
}

export function getTotalSegmentSeconds(segments: VoiceSegment[]): number {
  return segments.reduce((sum, segment) => sum + segment.durationSeconds, 0);
}

export type { VoiceSegment };
