import type { ChatInboxItem } from '@/constants/chatInbox';
import type { ConversationListItem } from '@/types/conversation.types';

function formatConversationTimestamp(iso: string | null): string {
  if (!iso) return '';

  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';

  const now = new Date();
  const isToday =
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth() &&
    date.getDate() === now.getDate();

  if (isToday) {
    return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }

  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday =
    date.getFullYear() === yesterday.getFullYear() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getDate() === yesterday.getDate();

  if (isYesterday) return 'Yesterday';

  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

export function mapConversationListItemToInbox(item: ConversationListItem): ChatInboxItem {
  const subject = item.subject?.trim() || 'Conversation';

  return {
    id: item.id,
    name: subject,
    lastMessage: item.last_message_preview?.trim() || 'No messages yet',
    timestamp: formatConversationTimestamp(item.last_message_at ?? item.updated_at),
    unreadCount: item.unread_count,
    isGroup: item.conversation_type !== 'standard',
    avatarInitial: subject.charAt(0).toUpperCase() || '?',
    isOnline: false,
    mode: item.conversation_type === 'standard' ? 'preview' : 'full',
  };
}
