import * as FileSystem from 'expo-file-system/legacy';

import { API_CONFIG } from '@/config';

const imageCache = new Map<string, string>();

export function getCachedAuthenticatedImage(
  uri: string,
  accessToken: string | null | undefined,
): string | null {
  if (!uri || !accessToken) return null;
  return imageCache.get(`${uri}::${accessToken.slice(0, 12)}`) ?? null;
}

export function attachmentUrlRequiresAuth(uri: string): boolean {
  if (!uri) return false;
  return uri.startsWith(API_CONFIG.BASE_URL);
}

export async function downloadAuthenticatedImage(
  uri: string,
  accessToken: string,
): Promise<string> {
  const cacheKey = `${uri}::${accessToken.slice(0, 12)}`;
  const cached = imageCache.get(cacheKey);
  if (cached) return cached;

  const fileName = `chat-attach-${Date.now()}.jpg`;
  const localPath = `${FileSystem.cacheDirectory}${fileName}`;

  const result = await FileSystem.downloadAsync(uri, localPath, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (result.status !== 200) {
    throw new Error(`Attachment download failed with status ${result.status}`);
  }

  imageCache.set(cacheKey, result.uri);
  return result.uri;
}
