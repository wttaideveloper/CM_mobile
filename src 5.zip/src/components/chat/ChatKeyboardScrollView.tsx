import React, { forwardRef } from 'react';
import { KeyboardChatScrollView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import type { ScrollViewProps } from 'react-native';
import type { KeyboardChatScrollViewProps } from 'react-native-keyboard-controller';

type Ref = React.ElementRef<typeof KeyboardChatScrollView>;

/** Visible gap between composer and keyboard / emoji panel. */
export const CHAT_COMPOSER_GAP = 10;

/** Small gap between last message and composer when keyboard is closed. */
export const CHAT_MESSAGE_COMPOSER_GAP = 8;

/** Baseline inner composer row height (input pill + padding). */
export const CHAT_COMPOSER_BASE_HEIGHT = 60;

type ChatKeyboardScrollViewProps = ScrollViewProps &
  KeyboardChatScrollViewProps & {
    inverted?: boolean;
    /** Measured height of the composer chrome (for multiline growth via extraContentPadding). */
    composerOffset?: number;
  };

export const ChatKeyboardScrollView = forwardRef<Ref, ChatKeyboardScrollViewProps>(
  ({ inverted, composerOffset, ...props }, ref) => {
    const { bottom } = useSafeAreaInsets();
    const composerHeight = composerOffset ?? CHAT_COMPOSER_BASE_HEIGHT;
    const offset = Math.max(composerHeight + bottom - CHAT_COMPOSER_GAP, CHAT_COMPOSER_GAP);

    return (
      <KeyboardChatScrollView
        ref={ref}
        inverted={inverted}
        automaticallyAdjustContentInsets={false}
        contentInsetAdjustmentBehavior="never"
        keyboardDismissMode="none"
        keyboardLiftBehavior="always"
        offset={offset}
        {...props}
      />
    );
  },
);

ChatKeyboardScrollView.displayName = 'ChatKeyboardScrollView';
