import * as FileSystem from 'expo-file-system/legacy';

import { API_CONFIG } from '@/config';

const mediaCache = new Map<string, string>();

function cacheKey(uri: string, accessToken: string): string {
  return `${uri}::${accessToken.slice(0, 12)}`;
}

function extensionFromFileName(fileName?: string, fallback = 'bin'): string {
  if (!fileName) return fallback;
  const parts = fileName.split('.');
  if (parts.length < 2) return fallback;
  return parts.pop()!.toLowerCase();
}

async function assertValidDownloadedFile(localUri: string, extension: string): Promise<void> {
  if (extension !== 'pdf') return;

  const response = await fetch(localUri);
  const buffer = await response.arrayBuffer();
  const bytes = new Uint8Array(buffer.slice(0, 4));
  const header = String.fromCharCode(...bytes);

  if (!header.startsWith('%PDF')) {
    await FileSystem.deleteAsync(localUri, { idempotent: true });
    throw new Error('Downloaded file is not a valid PDF');
  }
}

export function clearAuthenticatedAttachmentCache(uri: string, accessToken: string): void {
  mediaCache.delete(cacheKey(uri, accessToken));
}

export function getCachedAuthenticatedImage(
  uri: string,
  accessToken: string | null | undefined,
): string | null {
  if (!uri || !accessToken) return null;
  return mediaCache.get(cacheKey(uri, accessToken)) ?? null;
}

export function getCachedAuthenticatedAttachment(
  uri: string,
  accessToken: string | null | undefined,
): string | null {
  return getCachedAuthenticatedImage(uri, accessToken);
}

export function attachmentUrlRequiresAuth(uri: string): boolean {
  if (!uri) return false;
  return uri.startsWith(API_CONFIG.BASE_URL);
}

export async function downloadAuthenticatedAttachment(
  uri: string,
  accessToken: string,
  fileName?: string,
): Promise<string> {
  const key = cacheKey(uri, accessToken);
  const cached = mediaCache.get(key);
  if (cached) {
    const extension = extensionFromFileName(fileName, 'bin');
    try {
      await assertValidDownloadedFile(cached, extension);
      return cached;
    } catch {
      mediaCache.delete(key);
    }
  }

  const extension = extensionFromFileName(fileName, 'm4a');
  const localPath = `${FileSystem.cacheDirectory}chat-attach-${Date.now()}.${extension}`;

  const result = await FileSystem.downloadAsync(uri, localPath, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (result.status !== 200) {
    throw new Error(`Attachment download failed with status ${result.status}`);
  }

  await assertValidDownloadedFile(result.uri, extension);

  mediaCache.set(key, result.uri);
  return result.uri;
}

export async function downloadAuthenticatedImage(
  uri: string,
  accessToken: string,
): Promise<string> {
  return downloadAuthenticatedAttachment(uri, accessToken, 'image.jpg');
}
